"""AI Video Factory portable render core - etapa 1."""
__version__ = '0.1.0'
