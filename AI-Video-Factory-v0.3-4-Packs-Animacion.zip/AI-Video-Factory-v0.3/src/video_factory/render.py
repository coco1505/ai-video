"""Scene scheduler -> live frame pipe -> FFmpeg -> quality report and deliverables."""
import bisect
import json
import math
import shutil
import subprocess
from pathlib import Path
from PIL import Image, ImageDraw
from .project import load_project, public_project
from .voice import read_env, make_voice, probe_duration, word_timings, scene_bounds
from .visual import render_frame


def srt_timestamp(sec):
    ms = int(round(max(0,sec)*1000))
    return f'{ms//3600000:02}:{(ms//60000)%60:02}:{(ms//1000)%60:02},{ms%1000:03}'


def group_words(words):
    groups=[]
    current=[]
    for word in words:
        if current and (len(current)>=4 or word['end']-current[0]['start']>2.05):
            groups.append(current)
            current=[]
        current.append(word)
    if current: groups.append(current)
    return groups


def output_captions(words, path):
    groups=group_words(words)
    lines=[]
    for i,g in enumerate(groups,1):
        lines.extend([str(i),f"{srt_timestamp(g[0]['start'])} --> {srt_timestamp(g[-1]['end'])}",' '.join(w['text'] for w in g),''])
    path.write_text('\n'.join(lines),encoding='utf-8')
    return groups


def ffprobe_json(video):
    result=subprocess.run(['ffprobe','-v','error','-show_entries',
        'stream=codec_type,codec_name,width,height,r_frame_rate:format=duration',
        '-of','json',str(video)],check=True,capture_output=True,text=True)
    return json.loads(result.stdout)


def perform_qc(video, expected_w, expected_h, voice_source):
    data=ffprobe_json(video)
    video_stream=next((s for s in data['streams'] if s['codec_type']=='video'),{})
    audio_stream=next((s for s in data['streams'] if s['codec_type']=='audio'),{})
    duration=float(data['format'].get('duration') or 0)
    errors=[]
    if not video_stream: errors.append('No video stream')
    if (video_stream.get('width'),video_stream.get('height'))!=(expected_w,expected_h):
        errors.append('Incorrect dimensions')
    if not audio_stream: errors.append('No audio stream')
    if duration<.5: errors.append('Video too short')
    if video_stream.get('codec_name')!='h264': errors.append('Not H.264')
    if audio_stream.get('codec_name')!='aac': errors.append('Not AAC')
    return {'pass':not errors,'errors':errors,'duration_seconds':round(duration,2),
            'width':video_stream.get('width'),'height':video_stream.get('height'),
            'video_codec':video_stream.get('codec_name'),'audio_codec':audio_stream.get('codec_name'),
            'voice':voice_source,'limitations':'QC técnico básico. Revisión narrativa/visual humana aún pendiente.'}


def create_contact_sheet(video, output):
    info=ffprobe_json(video)
    dur=float(info['format'].get('duration') or 1)
    frames=[]
    for k in range(6):
        sec=max(.0,dur*(k+.5)/6)
        cmd=['ffmpeg','-hide_banner','-loglevel','error','-ss',str(sec),'-i',str(video),
             '-vf','scale=200:-1','-frames:v','1','-f','image2pipe','-vcodec','png','pipe:1']
        proc=subprocess.run(cmd, capture_output=True)
        if proc.returncode==0 and proc.stdout:
            import io
            frames.append(Image.open(io.BytesIO(proc.stdout)).convert('RGB'))
    if frames:
        sheet=Image.new('RGB',(200*len(frames),frames[0].height),(12,19,32))
        for i,frame in enumerate(frames):sheet.paste(frame,(i*200,0))
        sheet.save(output)


def make_video(project_file, out_dir, voice_provider='auto', width=None, height=None, fps=None):
    if not shutil.which('ffmpeg') or not shutil.which('ffprobe'):
        raise RuntimeError('FFmpeg y ffprobe son obligatorios: ejecuta python scripts/doctor.py')
    project=load_project(project_file)
    if width: project['width']=int(width)
    if height: project['height']=int(height)
    if fps: project['fps']=int(fps)
    w,h,rate=project['width'],project['height'],project['fps']
    if w%2 or h%2: raise ValueError('H.264 requiere dimensiones pares')
    out=Path(out_dir).resolve()
    out.mkdir(parents=True,exist_ok=True)
    repo=Path(__file__).resolve().parents[2]
    read_env(repo)
    script='\n'.join(s['narration'].strip() for s in project['scenes'])
    (out/'script.txt').write_text(script,encoding='utf-8')
    voice,alignment,voice_source=make_voice(script,out,provider=voice_provider)
    duration=probe_duration(voice)
    if duration<=.5: raise RuntimeError('Narration audio empty or too short')
    # Render to the voice duration, with slight tail for a readable final frame.
    duration=duration+.22
    bounds=scene_bounds(project,script,duration,alignment)
    words=word_timings(script,duration,alignment)
    caption_groups=output_captions(words,out/'captions.srt')
    count=math.ceil(duration*rate)
    target=out/'master.mp4'
    cmd=['ffmpeg','-y','-hide_banner','-loglevel','error','-f','rawvideo','-pix_fmt','rgb24',
         '-s',f'{w}x{h}','-r',str(rate),'-i','pipe:0','-i',str(voice),'-c:v','libx264',
         '-preset','veryfast','-crf','21','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k',
         '-movflags','+faststart','-t',str(duration),str(target)]
    log=out/'ffmpeg-error.log'
    with log.open('wb') as err:
        proc=subprocess.Popen(cmd,stdin=subprocess.PIPE,stderr=err)
        try:
            starts=[b[0] for b in bounds]
            for frame in range(count):
                now=frame/rate
                idx=min(len(bounds)-1,bisect.bisect_right(starts,now)-1)
                start,end=bounds[idx]
                image=render_frame(project['scenes'][idx],w,h,now,start,end,caption_groups)
                proc.stdin.write(image.tobytes())
                if frame % max(1,rate*5)==0:
                    print(f'Render: {frame}/{count} frames ({int(100*frame/count)}%)',flush=True)
        except BrokenPipeError:
            raise RuntimeError('FFmpeg cerró el pipe. Lee ffmpeg-error.log.') from None
        finally:
            if proc.stdin:
                try: proc.stdin.close()
                except OSError: pass
        code=proc.wait()
    if code!=0:
        raise RuntimeError(f'FFmpeg falló ({code}). Revisa {log}')
    qc=perform_qc(target,w,h,voice_source)
    (out/'qc-report.json').write_text(json.dumps(qc,ensure_ascii=False,indent=2),encoding='utf-8')
    if not qc['pass']:
        raise RuntimeError('QC falló: '+ '; '.join(qc['errors']))
    assets=[]
    for i,scene in enumerate(project['scenes']):
        if scene.get('asset'):
            assets.append({'scene':i,'local_file':scene['asset'],'source_url':scene['source_url'],
                           'license':scene['license'],'creator':scene.get('creator','no especificado')})
        elif scene['style'] in ('cinematic','archival','collage'):
            assets.append({'scene':i,'kind':'procedural_placeholder','note':'Visual generado por código; NO es stock real'})
    (out/'asset-manifest.json').write_text(json.dumps(assets,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'scene-timing.json').write_text(json.dumps([{'style':s['style'],'start':round(a,2),'end':round(b,2)}
                                         for s,(a,b) in zip(project['scenes'],bounds)],ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'cost-report.json').write_text(json.dumps({'voice_provider':voice_source,
        'api_spend_usd':'unknown: consult provider usage dashboard' if voice_source=='elevenlabs' else 0,
        'stock_spend_usd':0,'note':'No incluye créditos del agente ni otras infraestructuras.'},
        ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'project-used.json').write_text(json.dumps(public_project(project),ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'social-caption.txt').write_text(project.get('social_caption') or project.get('title','Video explicativo'),encoding='utf-8')
    sources=project.get('sources',[])
    (out/'sources.md').write_text('# Fuentes proporcionadas por el agente\n\n'+
        ('\n'.join('- '+str(src) for src in sources) if sources else 'No se proporcionaron fuentes. Revisión factual pendiente.'),
        encoding='utf-8')
    try:
        create_contact_sheet(target,out/'contact-sheet.png')
    except Exception as exc:
        print('Advertencia: contact sheet no disponible:',exc,flush=True)
    print(f'✓ MP4 generado: {target}\n✓ QC: {qc["pass"]}, {qc["duration_seconds"]} s; voz: {voice_source}')
    return target
