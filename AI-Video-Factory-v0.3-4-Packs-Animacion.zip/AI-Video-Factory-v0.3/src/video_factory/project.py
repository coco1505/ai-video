"""Validated intermediate video specification, with no agent/provider coupling."""
import json
from pathlib import Path

STYLES = ('kinetic', 'science', 'infographic', 'timeline', 'cinematic', 'archival', 'collage', 'map')


def load_project(path):
    p = Path(path).resolve()
    data = json.loads(p.read_text(encoding='utf-8'))
    if not isinstance(data, dict):
        raise ValueError('project.json tiene que ser un objeto')
    w, h = int(data.get('width', 720)), int(data.get('height', 1280))
    fps = int(data.get('fps', 24))
    if not (240 <= w <= 1920 and 400 <= h <= 3840 and 8 <= fps <= 60):
        raise ValueError('Resolución o FPS fuera de rango')
    if len(data.get('scenes', [])) < 1 or len(data['scenes']) > 60:
        raise ValueError('Se requiere entre 1 y 60 escenas')
    for i, scene in enumerate(data['scenes']):
        if scene.get('style') not in STYLES:
            raise ValueError(f'Escena {i}: estilo no soportado: {scene.get("style")}. Válidos: {STYLES}')
        if not isinstance(scene.get('narration'), str) or not scene['narration'].strip():
            raise ValueError(f'Escena {i} sin narración')
        if len(scene['narration']) > 1600:
            raise ValueError(f'Escena {i}: narración demasiado larga')
        if 'asset' in scene:
            a = Path(scene['asset'])
            if a.is_absolute() or '..' in a.parts:
                raise ValueError('Los assets deben ser rutas relativas dentro del proyecto')
            if not scene.get('license') or not scene.get('source_url'):
                raise ValueError(f'Escena {i}: asset sin licencia y URL de procedencia')
            resolved = (p.parent / a).resolve()
            if not resolved.is_relative_to(p.parent):
                raise ValueError('Asset fuera de la carpeta del proyecto')
            if not resolved.exists():
                raise FileNotFoundError(f'Asset faltante en escena {i}: {resolved}')
            scene['_asset_path'] = str(resolved)
        if 'events' in scene and not isinstance(scene['events'], list):
            raise ValueError(f'Escena {i}: events debe ser una lista')
    data['width'], data['height'], data['fps'] = w, h, fps
    data['_path'] = str(p)
    return data


def public_project(data):
    return {k: v for k, v in data.items() if not k.startswith('_')}
