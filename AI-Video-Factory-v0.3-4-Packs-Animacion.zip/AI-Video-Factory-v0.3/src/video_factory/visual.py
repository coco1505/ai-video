"""Eight functioning programmatic animation styles (not prompt-only)."""
import math
import random
from functools import lru_cache
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageOps

INK = '#eaf3fb'
MUTED = '#a3b7c9'
GOLD = '#ffcf76'
AQUA = '#6ee1d2'

FONT_CHOICES = [
    '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
    '/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf',
    '/Library/Fonts/Arial Bold.ttf',
    'C:/Windows/Fonts/arialbd.ttf',
]
REGULAR_CHOICES = [
    '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
    '/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf',
    '/Library/Fonts/Arial.ttf',
    'C:/Windows/Fonts/arial.ttf',
]


def fnt(size, regular=False):
    options = REGULAR_CHOICES if regular else FONT_CHOICES
    for path in options:
        if Path(path).exists():
            return ImageFont.truetype(path, max(10, int(size)))
    return ImageFont.load_default(size=max(10, int(size)))


def clamp(value, lo=0., hi=1.):
    return max(lo, min(hi, float(value)))


def ease(v):
    x = clamp(v)
    return 1 - (1-x)**3


def tcurve(t, delay=.0, period=.8):
    return ease((t-delay)/max(.0001, period))


def ellipse_box(x, y, r):
    return (int(x-r), int(y-r), int(x+r), int(y+r))


def lines_for(text, font, max_width):
    """Wrap on actual rendered pixel width; break long tokens instead of cropping."""
    measure = ImageDraw.Draw(Image.new('RGB', (1, 1)))
    output = []
    for para in str(text).split('\n'):
        words = para.split()
        current = ''
        for word in words:
            test = (current+' '+word).strip()
            if measure.textbbox((0, 0), test, font=font)[2] <= max_width:
                current = test
            else:
                if current:
                    output.append(current)
                    current = ''
                # handle a word longer than the allowed line width
                for char in word:
                    tmp = current + char
                    if measure.textbbox((0,0), tmp, font=font)[2] > max_width and current:
                        output.append(current)
                        current = char
                    else:
                        current = tmp
        if current:
            output.append(current)
    return output or ['']


def center_text(img, text, center_y, size, color=INK, max_width=.86, max_lines=5, regular=False, opacity=255):
    w, h = img.size
    font = fnt(size, regular)
    max_pixels = int(w * max_width)
    lines = lines_for(text, font, max_pixels)
    while len(lines)>max_lines and size>13:
        size -= 2
        font = fnt(size, regular)
        lines = lines_for(text, font, max_pixels)
    line_height = int(size*1.35)
    y = center_y-len(lines)*line_height/2
    layer = Image.new('RGBA', img.size, (0,0,0,0))
    draw = ImageDraw.Draw(layer)
    for ln in lines:
        bbox = draw.textbbox((0,0), ln, font=font)
        x = (w-(bbox[2]-bbox[0]))/2
        draw.text((x+2,y+3),ln, font=font, fill=(0,0,0,int(opacity*.55)))
        draw.text((x,y),ln, font=font, fill=(*Image.new('RGB',(1,1),color).getpixel((0,0)),opacity))
        y += line_height
    img.alpha_composite(layer)


@lru_cache(maxsize=24)
def background(w, h, style):
    palettes = {
        'kinetic': ((9,15,35), (21,43,72)),
        'science': ((5,14,32), (9,26,63)),
        'infographic': ((11,29,44), (8,58,75)),
        'timeline': ((13,20,42), (26,35,63)),
        'cinematic': ((3,7,19), (22,30,56)),
        'archival': ((29,24,25), (63,51,46)),
        'collage': ((13,20,29), (30,37,56)),
        'map': ((11,27,40), (14,55,67)),
    }
    top, bottom = palettes[style]
    grad = Image.new('RGB', (1, h))
    px = grad.load()
    for y in range(h):
        q=y/max(1,h-1)
        px[0,y] = tuple(int(a*(1-q)+b*q) for a,b in zip(top,bottom))
    canvas = grad.resize((w,h)).convert('RGBA')
    d = ImageDraw.Draw(canvas)
    rnd = random.Random(502)
    for _ in range(max(50,w*h//9000)):
        x=rnd.randint(0,w-1); y=rnd.randint(0,h-1)
        r=rnd.choice([0,0,1]); c=rnd.choice([50,70,90,115,140])
        d.ellipse((x,y,x+r,y+r),fill=(c,c+8,min(255,c+20),100))
    return canvas


def pill(img, xy, text, fill=(33,62,79,255), color=INK, size=19):
    x,y=xy
    draw=ImageDraw.Draw(img)
    font=fnt(size)
    bbox=draw.textbbox((0,0),text,font=font)
    tw=bbox[2]-bbox[0]
    pad=int(size*.75)
    draw.rounded_rectangle((x,y,x+tw+pad*2,y+size+pad),radius=int(size*.55),fill=fill)
    draw.text((x+pad,y+pad*.35),text,font=font,fill=color)


def paper_card(draw, box, fill, outline=None, radius=20, width=2):
    draw.rounded_rectangle(tuple(map(int,box)), radius=radius, fill=fill, outline=outline, width=width)


def draw_kinetic(img, scene, t, p):
    w,h=img.size
    d=ImageDraw.Draw(img)
    xoff=int((1-tcurve(t,0,.55))*w*.48)
    d.rounded_rectangle((int(w*.07)+xoff,int(h*.26),int(w*.93)+xoff,int(h*.63)),radius=34,fill=(22,41,69,250),outline=(73,143,169),width=3)
    d.rounded_rectangle((int(w*.10),int(h*.22),int(w*.38),int(h*.231)),radius=6,fill=AQUA)
    center_text(img,scene.get('headline') or scene['narration'], h*.445, int(w*.092),opacity=int(255*tcurve(t,.1,.5)))
    # Animated underline and index
    d.rounded_rectangle((int(w*.12),int(h*.666),int(w*(.12+.76*tcurve(t,.55,.5))),int(h*.674)),radius=5,fill=GOLD)
    pill(img,(int(w*.09),int(h*.12)),scene.get('eyebrow','DESCÚBRELO'), size=int(w*.034))


def draw_science(img, scene, t, p):
    w,h=img.size; d=ImageDraw.Draw(img)
    cx,cy=w*.50,h*.465
    radius=w*.34
    # orbit ellipse and guiding axes
    ry=h*.19
    d.ellipse((cx-radius,cy-ry,cx+radius,cy+ry), outline=(91,152,183),width=max(2,int(w*.003)))
    for i in range(6):
        r=w*(.076+i*.007)
        d.ellipse(ellipse_box(cx,cy,r),fill=(14+i*6,82+i*9,125+i*7),outline=(83,184,204),width=2)
    d.ellipse(ellipse_box(cx-w*.012,cy-h*.012,w*.055),fill=(74,170,146))
    # One orbit + one rotation with a fixed moon Earth-facing mark
    theta=-math.pi/2 + p*math.pi*2
    mx=cx+radius*math.cos(theta); my=cy+ry*math.sin(theta)
    moonr=w*.082
    d.line((mx,my,cx,cy),fill=(77,110,135),width=2)
    d.ellipse(ellipse_box(mx,my,moonr),fill=(196,208,214),outline=(245,250,252),width=3)
    for a,b,r in [(-.3,-.2,.18),(.25,.2,.14),(.10,-.45,.10)]:
        d.ellipse(ellipse_box(mx+a*moonr,my+b*moonr,r*moonr),fill=(144,159,166))
    # Mark on the Earth-facing lunar hemisphere. This is an explanatory schematic.
    vecx=cx-mx; vecy=cy-my
    norm=math.hypot(vecx,vecy) or 1
    markx=mx+vecx/norm*moonr*.72; marky=my+vecy/norm*moonr*.72
    d.ellipse(ellipse_box(markx,marky,w*.014),fill=GOLD)
    center_text(img,scene.get('headline','ROTACIÓN SINCRÓNICA'),h*.205,int(w*.061))
    center_text(img,scene.get('subhead','Una vuelta por cada órbita'),h*.265,int(w*.034),color=AQUA,regular=True)
    pill(img,(int(w*.08),int(h*.115)),'DIAGRAMA · NO A ESCALA',size=int(w*.026))


def draw_infographic(img, scene, t, p):
    w,h=img.size; d=ImageDraw.Draw(img)
    pill(img,(int(w*.085),int(h*.14)),'DATOS CLAVE',size=int(w*.032))
    center_text(img,scene.get('headline','EL DATO IMPORTANTE'),h*.32,int(w*.073))
    entries=scene.get('stats') or [{'label':'ROTACIÓN', 'value':'27.3 días'},{'label':'ÓRBITA','value':'27.3 días'}]
    for i,item in enumerate(entries[:3]):
        y=h*(.41+.105*i)
        d.rounded_rectangle((w*.09,y,w*.91,y+h*.11),radius=int(w*.025),fill=(21,61,78),outline=(56,111,128),width=2)
        d.rounded_rectangle((w*.12,y+h*.075,w*(.12+.61*tcurve(t,i*.22,.7)),y+h*.082),radius=4,fill=AQUA if i%2==0 else GOLD)
        font=fnt(int(w*.031),True)
        d.text((w*.13,y+h*.015),str(item.get('label','')).upper(),font=font,fill=(184,215,223))
        value=str(item.get('value',''))
        vf=fnt(int(w*.055))
        box=d.textbbox((0,0),value,font=vf)
        d.text((w*.87-(box[2]-box[0]),y+h*.013),value,font=vf,fill=GOLD)


def draw_timeline(img, scene, t, p):
    w,h=img.size; d=ImageDraw.Draw(img)
    pill(img,(int(w*.08),int(h*.12)),'LÍNEA DEL TIEMPO',size=int(w*.032))
    center_text(img,scene.get('headline','ASÍ SUCEDIÓ'),h*.265,int(w*.071))
    points=scene.get('events') or [{'year':'PASO 1','label':'Observación'},{'year':'PASO 2','label':'Descubrimiento'},{'year':'PASO 3','label':'Explicación'}]
    points=points[:4]
    start,end=h*.355,h*.615
    d.line((w*.23,start,w*.23,start+(end-start)*ease(p)), fill=AQUA,width=max(5,int(w*.009)))
    for i,item in enumerate(points):
        py=start+(end-start)*i/max(1,len(points)-1)
        alpha=tcurve(t,i*.28,.5)
        if alpha<.04: continue
        d.ellipse(ellipse_box(w*.23,py,w*.022),fill=GOLD,outline=INK,width=2)
        d.text((w*.30,py-w*.034),str(item.get('year','')),font=fnt(int(w*.042)),fill=GOLD)
        d.text((w*.30,py+w*.020),str(item.get('label',''))[:35],font=fnt(int(w*.034),True),fill=INK)


def _moon(draw, x,y,r, seed=7):
    draw.ellipse(ellipse_box(x,y,r),fill=(197,199,199),outline=(235,241,242),width=2)
    randomer=random.Random(seed)
    for i in range(35):
        dx=randomer.uniform(-.76,.76); dy=randomer.uniform(-.72,.72)
        if dx*dx+dy*dy>.73: continue
        sr=randomer.uniform(.015,.075)*r
        c=randomer.randint(137,179)
        draw.ellipse(ellipse_box(x+dx*r,y+dy*r,sr),fill=(c,c+1,c+6),outline=(c+19,c+20,c+22))


@lru_cache(maxsize=24)
def external_asset(path, w, h):
    image=Image.open(path).convert('RGB')
    return ImageOps.fit(image,(w,h),centering=(.5,.5)).convert('RGBA')


def asset_back(img, scene, t):
    if not scene.get('_asset_path'):
        return False
    w,h=img.size
    asset=external_asset(scene['_asset_path'],w,h)
    # Gentle zoom; source image is licensed and attributed in manifest.
    zoom=1.0+min(.065,t*.016)
    nw,nh=int(w*zoom),int(h*zoom)
    asset=asset.resize((nw,nh),Image.Resampling.BICUBIC)
    asset=asset.crop(((nw-w)//2,(nh-h)//2,(nw+w)//2,(nh+h)//2))
    img.alpha_composite(asset)
    img.alpha_composite(Image.new('RGBA',(w,h),(0,6,15,110)))
    return True


def draw_cinematic(img, scene,t,p):
    w,h=img.size
    has_asset=asset_back(img,scene,t)
    d=ImageDraw.Draw(img)
    if not has_asset:
        mx=w*.66-tcurve(t,0,5)*w*.07
        my=h*.42
        _moon(d,mx,my,w*.32,17)
        d.ellipse((w*.09,h*.22,w*.94,h*.64),outline=(76,92,118),width=2)
    d.rectangle((0,int(h*.67),w,h),fill=(3,11,23,221))
    pill(img,(int(w*.08),int(h*.10)),'DOCUMENTAL',size=int(w*.032))
    center_text(img,scene.get('headline') or 'LA HISTORIA OCULTA',h*.588,int(w*.073),max_lines=3)
    center_text(img,scene.get('subhead','Una explicación visual'),h*.655,int(w*.031),color=MUTED,regular=True)


def draw_archival(img,scene,t,p):
    w,h=img.size
    d=ImageDraw.Draw(img)
    has_asset=asset_back(img,scene,t)
    if not has_asset:
        paper=(207,186,149)
        frame=(w*.09,h*.23,w*.91,h*.66)
        d.rounded_rectangle(frame,radius=6,fill=paper,outline=(242,218,170),width=5)
        d.ellipse(ellipse_box(w*.52,h*.435,w*.19),fill=(100,99,88))
        for i in range(4):
            dx=(i-1.5)*w*.08
            d.ellipse(ellipse_box(w*.52+dx,h*.45,w*.024),fill=(142,137,116))
    # moving fine grain + cinematic barcode markers
    rnd=random.Random(int(t*15)+73)
    for _ in range(90):
        x=rnd.randrange(w); y=rnd.randrange(h)
        d.point((x,y),fill=(159,152,133,75))
    d.rectangle((0,int(h*.705),w,h),fill=(22,20,22,246))
    pill(img,(int(w*.085),int(h*.11)),'ARCHIVO / HISTORIA',fill=(71,58,46),color=GOLD,size=int(w*.03))
    center_text(img,scene.get('headline','UN HECHO HISTÓRICO'),h*.19,int(w*.058))


def draw_collage(img,scene,t,p):
    w,h=img.size; d=ImageDraw.Draw(img)
    for j,(x,y,ww,hh,clr) in enumerate([
        (.09,.22,.54,.37,(68,113,135)),
        (.49,.32,.40,.28,(165,133,95)),
        (.16,.47,.55,.18,(60,112,110)),
    ]):
        k=tcurve(t,j*.22,.7)
        y2=int((y+.14*(1-k))*h)
        rect=(int(x*w),y2,int((x+ww)*w),y2+int(hh*h))
        d.rounded_rectangle(rect,radius=18,fill=clr,outline=(218,226,220),width=3)
        d.line((rect[0]+15,rect[3]-30,rect[2]-15,rect[1]+30), fill=(231,224,205),width=max(2,int(w*.004)))
        d.ellipse(ellipse_box(rect[2]-w*.11,rect[1]+h*.07,w*.05),outline=(238,226,186),width=4)
    d.rectangle((0,int(h*.75),w,h),fill=(4,13,22,244))
    pill(img,(int(w*.08),int(h*.12)),'COLLAGE EDITORIAL',size=int(w*.032))
    center_text(img,scene.get('headline','CONECTA LAS PIEZAS'),h*.19,int(w*.065))


def draw_map(img,scene,t,p):
    w,h=img.size; d=ImageDraw.Draw(img)
    left,top,right,bottom=w*.09,h*.26,w*.91,h*.71
    d.rounded_rectangle((left,top,right,bottom),radius=16,fill=(16,48,67),outline=(85,146,150),width=3)
    for j in range(1,8):
        x=left+(right-left)*j/8
        d.line((x,top+10,x,bottom-10),fill=(39,83,99),width=2)
    for j in range(1,9):
        y=top+(bottom-top)*j/10
        d.line((left+10,y,right-10,y),fill=(39,83,99),width=2)
    route=scene.get('points') or [[.12,.68],[.39,.35],[.66,.52],[.88,.20]]
    pts=[]
    for item in route[:10]:
        if not (isinstance(item,list) and len(item)==2): continue
        pts.append((int(left+(right-left)*clamp(item[0])),int(top+(bottom-top)*clamp(item[1]))))
    for a,b in zip(pts,pts[1:]):
        d.line((a,b),fill=(58,106,115),width=6)
    for i,(x,y) in enumerate(pts):
        if tcurve(t,i*.24,.3)<.1: continue
        d.ellipse(ellipse_box(x,y,w*.018),fill=GOLD,outline=INK,width=2)
    pill(img,(int(w*.09),int(h*.12)),'MAPA ILUSTRATIVO',size=int(w*.031))
    center_text(img,scene.get('headline','UNA RUTA PARA ENTENDER'),h*.20,int(w*.065))


def draw_captions(img, caption_words, now):
    w,h=img.size
    current=None
    for group in caption_words:
        if group[0]['start']<=now<group[-1]['end']+.09:
            current=group
            break
    if not current: return
    txt=' '.join(item['text'] for item in current)
    # Bottom third but above common mobile interface safe areas.
    font=fnt(int(w*.049))
    lines=lines_for(txt,font,int(w*.80))
    if len(lines)>2:
        font=fnt(int(w*.038))
        lines=lines_for(txt,font,int(w*.80))[:3]
    y=h*.755
    line_h=int(font.size*1.4)
    d=ImageDraw.Draw(img)
    bg_top=y-14
    bg_bottom=y+len(lines)*line_h+17
    d.rounded_rectangle((w*.065,bg_top,w*.935,bg_bottom),radius=14,fill=(3,13,23,225))
    for ln in lines:
        bb=d.textbbox((0,0),ln,font=font)
        x=(w-(bb[2]-bb[0]))/2
        d.text((x+1,y+2),ln,font=font,fill=(0,0,0))
        d.text((x,y),ln,font=font,fill=INK)
        y+=line_h


def render_frame(scene, w, h, now, start, end, captions):
    t=max(0,now-start)
    p=clamp(t/max(.001,end-start))
    style=scene['style']
    img=background(w,h,style).copy()
    {'kinetic':draw_kinetic,'science':draw_science,'infographic':draw_infographic,
     'timeline':draw_timeline,'cinematic':draw_cinematic,'archival':draw_archival,
     'collage':draw_collage,'map':draw_map}[style](img,scene,t,p)
    draw_captions(img,captions,now)
    return img.convert('RGB')
