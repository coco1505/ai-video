"""ElevenLabs time-aligned voice, and explicit local demo fallback."""
import base64
import json
import os
import sys
import shutil
import subprocess
import urllib.error
import urllib.request
from pathlib import Path


def read_env(root):
    env_file = Path(root) / '.env'
    if env_file.exists():
        for raw in env_file.read_text(encoding='utf-8').splitlines():
            raw = raw.strip()
            if raw and not raw.startswith('#') and '=' in raw:
                k, v = raw.split('=', 1)
                os.environ.setdefault(k.strip(), v.strip().strip('\"').strip("'"))


def probe_duration(file):
    cmd = ['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'default=noprint_wrappers=1:nokey=1', str(file)]
    result = subprocess.run(cmd, check=True, capture_output=True, text=True)
    return float(result.stdout.strip())


def make_voice(text, output_dir, provider='auto'):
    output_dir = Path(output_dir)
    key = os.getenv('ELEVENLABS_API_KEY', '').strip()
    if provider == 'auto':
        provider = 'elevenlabs' if key else 'local'
    if provider == 'elevenlabs':
        if not key:
            raise RuntimeError('Falta ELEVENLABS_API_KEY en .env. Usa --voice espeak sólo como demo local.')
        voice_id = os.getenv('ELEVENLABS_VOICE_ID', '21m00Tcm4TlvDq8ikWAM')
        model = os.getenv('ELEVENLABS_MODEL_ID', 'eleven_multilingual_v2')
        url = f'https://api.elevenlabs.io/v1/text-to-speech/{voice_id}/with-timestamps'
        request = urllib.request.Request(
            url,
            data=json.dumps({'text': text, 'model_id': model}).encode('utf-8'),
            headers={'xi-api-key': key, 'Content-Type': 'application/json', 'Accept': 'application/json'},
            method='POST'
        )
        try:
            with urllib.request.urlopen(request, timeout=120) as res:
                response = json.load(res)
        except urllib.error.HTTPError as err:
            detail = err.read(350).decode('utf-8', errors='replace')
            raise RuntimeError(f'ElevenLabs HTTP {err.code}: {detail}') from None
        if not response.get('audio_base64'):
            raise RuntimeError('ElevenLabs no devolvió audio_base64')
        audio = output_dir / 'narration.mp3'
        audio.write_bytes(base64.b64decode(response['audio_base64']))
        alignment = response.get('alignment') or response.get('normalized_alignment')
        return audio, alignment, 'elevenlabs'
    if provider in ('espeak','local'):
        executable = shutil.which('espeak-ng') or shutil.which('espeak')
        if executable:
            audio = output_dir / 'narration.wav'
            subprocess.run([executable, '-v', 'es-la', '-s', '145', '-w', str(audio), text], check=True)
            return audio, None, 'espeak (demo, voz robótica)'
        if provider == 'espeak':
            raise RuntimeError('espeak o espeak-ng no está instalado. Instala espeak-ng o usa ElevenLabs.')
        if sys.platform == 'darwin' and shutil.which('say'):
            audio = output_dir / 'narration.aiff'
            subprocess.run(['say','-o',str(audio),text],check=True)
            return audio, None, 'macOS say (demo, timestamps estimados)'
        if os.name == 'nt' and (shutil.which('powershell') or shutil.which('powershell.exe')):
            audio = output_dir / 'narration.wav'
            source = output_dir / 'speech-text.txt'
            source.write_text(text,encoding='utf-8')
            def q(path):
                return str(path).replace("'","''")
            code = ("Add-Type -AssemblyName System.Speech; "
                    "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
                    "$s.SetOutputToWaveFile('"+q(audio)+"'); "
                    "$s.Speak([System.IO.File]::ReadAllText('"+q(source)+"')); "
                    "$s.Dispose()")
            subprocess.run(['powershell','-NoProfile','-Command',code],check=True)
            source.unlink(missing_ok=True)
            return audio, None, 'Windows SAPI (demo, timestamps estimados)'
        raise RuntimeError('No existe voz local disponible. Configura ElevenLabs, o instala espeak-ng. No se exporta en silencio.')
    raise ValueError('Proveedor de voz no admitido: ' + provider)


def word_timings(text, total_duration, alignment=None):
    """Return true character-derived times when supplied, otherwise estimated times."""
    import re
    words = list(re.finditer(r'\S+', text))
    if alignment:
        starts = alignment.get('character_start_times_seconds', [])
        ends = alignment.get('character_end_times_seconds', [])
        chars = alignment.get('characters', [])
        if len(starts) >= len(text) and len(ends) >= len(text) and ''.join(chars) == text:
            return [{'text': m.group(), 'start': float(starts[m.start()]), 'end': float(ends[m.end()-1]), 'estimated': False} for m in words]
    # Heuristic is only for demo/non-timestamped audio.
    count = max(1, len(text))
    duration = max(0.1, total_duration - 0.25)
    return [{'text': m.group(), 'start': duration*m.start()/count, 'end': duration*m.end()/count, 'estimated': True} for m in words]


def scene_bounds(project, text, duration, alignment=None):
    narrations = [s['narration'].strip() for s in project['scenes']]
    offsets = []
    cursor = 0
    for t in narrations:
        offsets.append((cursor, cursor+len(t)))
        cursor += len(t)+1
    if alignment and ''.join(alignment.get('characters', [])) == text:
        ends = alignment.get('character_end_times_seconds', [])
        if len(ends) == len(text):
            points = [0.] + [float(ends[end-1]) for _, end in offsets[:-1]] + [duration]
            # Fast validation against zero-length scenes / bad alignments
            if all(points[i+1]-points[i] > .1 for i in range(len(points)-1)):
                return list(zip(points[:-1], points[1:]))
    # Weighted by characters, not fixed 5-second footage.
    weights = [max(8, len(x)) for x in narrations]
    cum = [0.]
    for n in weights:
        cum.append(cum[-1] + duration*n/sum(weights))
    cum[-1] = duration
    return list(zip(cum[:-1], cum[1:]))
