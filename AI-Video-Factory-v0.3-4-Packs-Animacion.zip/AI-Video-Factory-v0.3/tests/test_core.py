import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'src'))
from video_factory.project import STYLES, load_project
from video_factory.visual import render_frame
from video_factory.voice import word_timings

class Tests(unittest.TestCase):
    def test_project(self):
        project=load_project(root/'projects/moon_demo.json')
        self.assertEqual(project['language'],'es-MX')
        self.assertEqual(len(project['scenes']),6)
    def test_styles_draw(self):
        for style in STYLES:
            scene={'style':style,'narration':'Texto de prueba','headline':'TÍTULO DE PRUEBA'}
            frame=render_frame(scene,360,640,1.,0.,3.,[])
            self.assertEqual(frame.size,(360,640))
    def test_alignment(self):
        text='Hola Luna'
        alignment={'characters':list(text),
                   'character_start_times_seconds':[i*.1 for i in range(len(text))],
                   'character_end_times_seconds':[(i+1)*.1 for i in range(len(text))]}
        words=word_timings(text,4,alignment)
        self.assertEqual(len(words),2)
        self.assertFalse(words[0]['estimated'])
        self.assertAlmostEqual(words[1]['start'],.5)
    def test_reject_unlicensed_asset(self):
        doc={'scenes':[{'style':'cinematic','narration':'foo','asset':'abc.png'}]}
        with tempfile.TemporaryDirectory() as t:
            file=Path(t)/'bad.json';file.write_text(json.dumps(doc))
            with self.assertRaises(ValueError):load_project(file)

if __name__=='__main__':unittest.main()
