import importlib.util
import json
import re
import sys
import tempfile
import unittest
from html.parser import HTMLParser
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import engines

class HTMLFacts(HTMLParser):
    def __init__(self):
        super().__init__()
        self.root=[];self.clips=[];self.scripts=[];self._in_script=False
    def handle_starttag(self,tag,attrs):
        attrs=dict(attrs)
        if attrs.get('data-composition-id')=='root': self.root.append(attrs)
        if 'clip' in attrs.get('class','').split(): self.clips.append(attrs)
        if tag=='script': self._in_script=True
    def handle_endtag(self,tag):
        if tag=='script': self._in_script=False
    def handle_data(self,data):
        if self._in_script:self.scripts.append(data)

class EnginesTests(unittest.TestCase):
    def setUp(self):
        self.project=engines.load_project(ROOT/'projects/moon_demo.json')
    def test_remotion_props(self):
        with tempfile.TemporaryDirectory() as t:
            data,audio=engines.prepare(self.project,'none',Path(t))
            self.assertIsNone(audio)
            self.assertEqual(len(data['scenes']),6)
            self.assertGreater(data['duration'],20)
            self.assertEqual(data['scenes'][0]['start'],0)
            self.assertTrue(all(s['end']>s['start'] for s in data['scenes']))
            self.assertEqual(data['width'],720)
            props=engines.remotion_props(data,None,'demo')
            self.assertEqual(props['title'],self.project['title'])
            self.assertNotIn('audioSrc',props)
            self.assertEqual(props['scenes'][2]['style'],'science')
    def test_hyperframes_contract(self):
        with tempfile.TemporaryDirectory() as t:
            props,_=engines.prepare(self.project,'none',Path(t))
            path=engines.generate_hyperframes(props,Path(t)/'composition')
            doc=path.read_text()
            parsed=HTMLFacts(); parsed.feed(doc)
            self.assertEqual(len(parsed.root),1)
            self.assertEqual(parsed.root[0]['data-width'],'720')
            self.assertEqual(parsed.root[0]['data-height'],'1280')
            self.assertEqual(len(parsed.clips),6)
            for i,x in enumerate(parsed.clips):
                for field in ('data-duration','data-start','data-track-index'):self.assertIn(field,x)
                self.assertEqual(x['data-track-index'],'0')
                self.assertEqual(float(x['data-start']),props['scenes'][i]['start'])
            self.assertIn('gsap.timeline({paused:true})',doc)
            self.assertIn('window.__timelines["root"]=tl',doc)
            self.assertIn('¿LA LUNA NO GIRA?',doc)
            self.assertTrue((path.parent/'video-props.json').is_file())
            self.assertEqual(json.loads((path.parent/'video-props.json').read_text())['width'],720)
    def test_html_escape(self):
        with tempfile.TemporaryDirectory() as t:
            props,_=engines.prepare(self.project,'none',Path(t))
            props['scenes'][0]['headline']='<script>bad</script> & test'
            html=engines.generate_hyperframes(props,Path(t)/'comp').read_text()
            self.assertIn('&lt;script&gt;bad&lt;/script&gt; &amp; test',html)
            self.assertNotIn('<script>bad</script>',html)
    def test_skills_and_source(self):
        skills=list((ROOT/'.agents/skills').glob('*/SKILL.md'))
        self.assertGreaterEqual(len(skills),22)
        self.assertTrue((ROOT/'engines/remotion/src/film.tsx').exists())
        self.assertTrue((ROOT/'package.json').exists())
        package=json.loads((ROOT/'package.json').read_text())
        self.assertEqual(package['dependencies']['remotion'],package['dependencies']['@remotion/cli'])
        self.assertTrue((ROOT/'docs/LICENSING.md').exists())
if __name__=='__main__': unittest.main()
