import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('style_packs',ROOT/'scripts/style_packs.py')
m=importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

class StylePacksTests(unittest.TestCase):
    def test_expected_four_packs(self):
        self.assertEqual(set(m.PACKS), {'lemo-opuscar','claude-animation-base','paper-shaders','hyperframes-core-skills'})
    def test_official_allowlisted_repositories(self):
        self.assertEqual(m.PACKS['lemo-opuscar']['source'],'https://github.com/lemomo-ai/lemo-opuscar.git')
        self.assertEqual(m.PACKS['claude-animation-base']['source'],'https://github.com/JohnHeibel/ClaudeAnimationBase.git')
    def test_dry_run_never_runs_commands(self):
        with patch.object(m,'run_checked') as run,patch.object(m,'installed',return_value=False):
            m.install('paper-shaders',execute=False)
            m.install('hyperframes-core-skills',execute=False)
            run.assert_not_called()
    def test_json_sources_in_repo(self):
        doc=json.loads((ROOT/'config/style-packs.json').read_text(encoding='utf-8'))
        self.assertEqual(doc['schema'],1)
        self.assertEqual(len(doc['packs']),4)
    def test_paper_remotion_optional_not_imported_by_main(self):
        original=(ROOT/'engines/remotion/src/index.ts').read_text(encoding='utf-8')
        self.assertNotIn('paper-film',original)
        self.assertTrue((ROOT/'engines/remotion/src/paper-index.ts').is_file())

if __name__=='__main__':unittest.main()
