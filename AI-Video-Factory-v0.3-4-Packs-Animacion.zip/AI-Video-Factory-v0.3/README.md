# AI VIDEO FACTORY · v0.3 — Remotion + HyperFrames + 4 packs de estilos

**Carpeta experimental para abrir en Codex, Claude Code o Antigravity** y encargar videos en español a partir de una idea. Cuenta con skills de producción y animación, guiones/escenas en JSON y tres motores seleccionables:

| Motor | Uso principal | Estado v0.2 |
|---|---|---|
| **Remotion** (React / SVG) | Videos narrados, infografías, explicaciones científicas y escenas con animación por fotograma | Código funcional escrito, CLI/npm requeridos para comprobar render local |
| **HyperFrames** (HeyGen / HTML / GSAP) | Motion graphics, tipografía cinética, infografías y timelines con composición HTML | Generador y ejemplo HTML presentes; CLI/npm externos para render |
| **Legacy** (Pillow / FFmpeg) | Respaldo y pruebas rápidas, ocho estilos animados con narración y captions | Render MP4 probado previamente en Linux |

**IMPORTANTE:** El ZIP contiene el **código de integración y las skills propias**, NO contiene los paquetes npm o los binarios ni las skills oficiales descargadas de Remotion/HyperFrames. Codex los instala de sus autores cuando hay internet. Esta sesión no tiene acceso al registro npm, así que el render real con Remotion/HyperFrames y la instalación de esas skills oficiales **no se han podido verificar todavía**. Los archivos Remotion/HyperFrames no son un MP4 garantizado hasta superar la prueba en tu equipo.

## Prueba en un Codex completamente limpio

1. Descomprime el ZIP entero y abre **esta carpeta raíz** como proyecto en Codex. No necesitas skills globales: las skills propias están en `.agents/skills/` y `.claude/skills/`.
2. Envía este texto al agente:

   > Lee AGENTS.md. Prepara AI Video Factory v0.2, revisa sus skills locales, instala Remotion y HyperFrames desde sus fuentes oficiales (incluidas las skills oficiales para Codex) y genera un video vertical sobre por qué siempre vemos la misma cara de la Luna. Primero utiliza Remotion. Después crea un motion graphic de 10 segundos con HyperFrames. Ejecuta controles técnicos y explica cualquier fallo real. Si falta ElevenLabs, utiliza voz de demostración y avisa que es robótica.

3. Codex puede ejecutar `python scripts/engines.py doctor`, `python scripts/engines.py install --skills --agent codex`, y los comandos de render de abajo.
4. Autoriza instalaciones de dependencias del proyecto si aceptas que descargue paquetes; para instalaciones administrativas del sistema y uso de APIs con costo, autoriza explícitamente cada gasto/cambio.
5. Abre los archivos bajo `output/`. Asegúrate de que Codex compruebe el archivo MP4 con `ffprobe` antes de decir que terminó.

## Requisitos

- **Node.js 22 o superior** (requerido por HyperFrames), npm/npx e internet al instalar.
- **FFmpeg + ffprobe** en `PATH` para los renders.
- **Python 3.10+** y Pillow para el renderer legacy. `python scripts/setup.py` instala dependencias Python en `.venv`.
- **ElevenLabs opcional** en `.env` (API de pago). Sin esa clave: voz demo local si hay `espeak-ng`, `say` o SAPI disponible.
- Navegador/Chromium compatible para los nuevos motores; los CLIs facilitan su preparación. Windows/macOS no han sido comprobados de punta a punta en esta versión.

## Instalar motores y skills oficiales

```bash
python scripts/engines.py doctor
python scripts/engines.py install --skills --agent codex
```

Ese comando ejecuta `npm install` para paquetes Remotion/React y luego instala las skills oficiales mediante el instalador `skills` desde `remotion-dev/skills` y `heygen-com/hyperframes`. **Requiere conexión a internet** y ejecuta código suministrado por terceros; verifica los paquetes y las fuentes antes de autorizar la instalación. Las skills propias de video/animación YA vienen en el ZIP.

Si sólo deseas instalar motor Remotion sin agregar skills externas: `python scripts/engines.py install`.

## Crear videos reales

```bash
# Remotion, video narrado: genera props, audio, subtítulos cronometrados y MP4.
python scripts/engines.py render --engine remotion --project projects/moon_demo.json --voice auto --out output/luna-remotion.mp4

# HyperFrames, video narrado: genera HTML/GSAP, lint, check y renderiza.
python scripts/engines.py render --engine hyperframes --project projects/moon_demo.json --voice auto --out output/luna-hyperframes.mp4

# Para probar el pipeline de HTML sin descargar dependencias ni usar voz:
python scripts/engines.py generate --engine hyperframes --project projects/moon_demo.json --voice none --out output/composicion-hyperframes

# Para obtener props de Remotion sin usar voz:
python scripts/engines.py generate --engine remotion --project projects/moon_demo.json --voice none --out output/props-remotion.json

# Renderer v0.1 de respaldo (si tienes Pillow + voz local):
python scripts/setup.py
.venv/bin/python scripts/make_video.py --project projects/moon_demo.json --out output/luna-legacy --voice auto
```

Windows (PowerShell) para Python venv: `.venv\Scripts\python.exe scripts\make_video.py ...`.

**Evitar gastos no consentidos:** `--voice auto` utiliza ElevenLabs cuando detecta tu clave (consumirá créditos). En Codex, pide explícitamente que confirme antes de la primera solicitud de voz de pago. Usa `--voice none` para generar los dos motores sin narración durante una prueba visual; `--voice local` para demo con voz del sistema.

## Cómo están conectados

`projects/moon_demo.json` → `scripts/engines.py` → voz y tiempos de escenas → `Remotion props JSON + React`, o `HyperFrames HTML + GSAP` → MP4.

Las escenas tienen los estilos `kinetic`, `science`, `infographic`, `timeline`, `cinematic`, `archival`, `collage`, `map`. Los estilos nuevos aportan animación real a títulos, órbitas esquemáticas, timelines y tarjetas; **cinematic/archival/collage siguen usando visuales procedurales hasta añadir metraje licenciado**. No hay 3D verdadero todavía, compositor híbrido completo, búsqueda autónoma de stock ni música comercial.

**Venta:** lee `docs/LICENSING.md`: Remotion NO es open source según su propia licencia y tiene condiciones diferentes según usuarios/organizaciones. Los motores de terceros no se pueden revender como si fueran código nuestro. Las claves y licencias de la API y medios corresponden al usuario.

Ver `AGENTS.md` (instrucciones), `docs/ACCEPTANCE.md`, `docs/SCHEMA.md`, `docs/ROADMAP.md`, `engines/remotion/README.md` y `engines/hyperframes/README.md`.

---

## Novedades v0.3: cuatro packs avanzados (opcionales)

**¡La versión de esta carpeta es v0.3!** Incorpora un gestor para descargar las fuentes oficiales de **Lemo-Opuscar (66 estilos anunciados), Claude Animation Base (p5.js/p5.brush), Paper Shaders (React/vanilla) y las skills principales oficiales de HyperFrames**, sin interferir con Remotion/HyperFrames/legacy.

```bash
python scripts/style_packs.py doctor
python scripts/style_packs.py list
python scripts/style_packs.py install --pack all           # simulación de instalación
python scripts/style_packs.py install --pack all --execute   # instala con internet y autorización
python scripts/style_packs.py catalog --pack lemo-opuscar  # lista los STYLE.md disponibles
```

**No todo es un motor**: HyperFrames es motor HTML de video, Lemo-Opuscar es una biblioteca con herramientas y estilos optimizados para Claude Opus 5.5, Claude Animation Base es un proyecto de referencia para cartoon p5, Paper Shaders una librería de shaders WebGL. Los tres últimos NO se integran automáticamente como modos verificables de `scripts/engines.py`: lo que sí agregamos son instaladores, skills de uso, guías de orquestación y una composición Remotion que usa Paper Shaders.

Para renderizar una demo **real** de Paper Shaders tras instalar dependencias:

```bash
python scripts/style_packs.py install --pack paper-shaders --execute
npm run paper:render:demo
```

Revisa `docs/THIRD_PARTY_STYLE_PACKS.md`, `docs/STYLE_SELECTION.md`, `docs/SHADERS.md`. Las fuentes originales no se distribuyen en el ZIP, pues se descargan en el equipo del usuario. Ni paquetes externos ni sus renders fueron comprobados con internet en este entorno.
