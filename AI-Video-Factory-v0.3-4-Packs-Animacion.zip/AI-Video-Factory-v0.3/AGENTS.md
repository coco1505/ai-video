# AI VIDEO FACTORY v0.3 — AGENT CONTRACT (CODEX / ANTIGRAVITY)

**Tu objetivo es entregar un MP4 verificable y no solo explicar cómo producirlo.** Este repositorio contiene 26 skills propias para guion, edición y animación, y contiene el código fuente de puentes para Remotion y HyperFrames. La CLI y las skills de terceros se instalan desde internet: NO asumas que ya están instaladas.

## PRIMERA TAREA OBLIGATORIA

1. Lee README.md y `.agents/skills/video-director/SKILL.md`, `.agents/skills/engine-router/SKILL.md`, y la skill del motor solicitado.
2. Si el usuario menciona **Remotion** o **HyperFrames**, respeta esa elección. No cambies silenciosamente al motor legacy.
3. Comprueba con `python scripts/engines.py doctor` y `python scripts/doctor.py`. Para los motores nuevos, Node.js **22+**, npm/npx y FFmpeg/ffprobe son obligatorios.
4. Con autorización apropiada para instalar dependencias de terceros, `python scripts/engines.py install --skills --agent codex` descarga paquetes oficiales Remotion desde npm y skills oficiales desde `remotion-dev/skills` y `heygen-com/hyperframes`. En Claude Code usa `--agent claude-code` y en Gemini CLI `--agent gemini-cli`. Las skills propias ya están en `.agents/skills/` y `.claude/skills/`.
5. Si faltan Node 22, FFmpeg o Python, consulta al usuario antes de modificar paquetes de sistema con permisos administrativos; instalar paquetes locales `npm install` necesita red.
6. Elección de voz: `auto` usa `ELEVENLABS_API_KEY` en `.env` y consume créditos si existe; **pide autorización antes de cualquier petición de voz que tenga costo**. Sin permiso usa `--voice local` como demostración o `--voice none` sin audio. Nunca compartas claves en el chat, código o logs.

## PIPELINE DE VIDEO

1. Brief: tema, duración, formato, idioma, estilo. Si faltan: 9:16, 30–60 segundos, español de México.
2. Investiga hechos con fuentes verificables y conserva URLs REALES en JSON `sources`. No inventes fuentes ni atribuciones.
3. Guion propio: hook inmediato + progresión + cierre, 4–10 escenas con nueva información en cada una. `projects/moon_demo.json` es ejemplo editable. Usa `docs/SCHEMA.md`.
4. Motor: `remotion` para video narrado/informativo con animaciones React/SVG, `hyperframes` para HTML/GSAP y gráficos cortos, `legacy` como respaldo sólo si el usuario no exige motor. `engines/remotion/src/film.tsx` y `scripts/engines.py` son código, no instrucciones genéricas.
5. Comandos reales:
   - `python scripts/engines.py render --engine remotion --project projects/<slug>.json --voice auto --out output/<slug>-remotion.mp4`
   - `python scripts/engines.py render --engine hyperframes --project projects/<slug>.json --voice auto --out output/<slug>-hyperframes.mp4`
   - `python scripts/make_video.py --project projects/<slug>.json --out output/<slug>-legacy --voice auto` (respaldo probado).
6. Para HyperFrames la secuencia es: HTML/GSAP -> `lint` -> `check --json` -> `snapshot` -> `render --quality looks`; revisa imágenes representativas y errores. Para Remotion revisa Studio o stills y corrige clipping/overflow.
7. Corre `ffprobe` sobre cada MP4 y confirma video, audio cuando se pidió voz, duración y formato. No digas que se generó si no existe. Analiza fotogramas cuando las herramientas lo permitan. Archivo HTML o JSON **no equivale a render MP4**.
8. Entrega el MP4 y explica claramente los límites: contenido sin stock auténtico, calidad demo de voz local, o fallos de instalación por internet. La calidad visual es una prueba de la iteración y no un éxito automático.

## DISEÑO VISUAL

- Frame 0 con idea visible; gancho de 1–3 segundos, titular legible y alto contraste.
- Transiciones motivadas por contenido; no solo fades repetidos. Mantén safe zones para subtítulos (centro inferior pero fuera de UI).
- `science`: diagramas esquemáticos no a escala. Para la Luna, explicar rotación síncrona sin afirmar que su cara oculta nunca recibe luz.
- `cinematic`, `archival`, `collage`: por ahora pueden dibujar fondos procedurales. NO los llames stock real o evidencia histórica.
- Los motores nuevos usan el mismo `project.json`; no hay un compositor mixto listo para combinar automáticamente clips de ambos motores.

## COMERCIAL Y SEGURIDAD

- Consulta `docs/LICENSING.md` antes de vender. No redistribuir binarios/código de terceros sin licencia; Remotion usa licencia propietaria.
- No copiar assets protegidos ni saltarse pagos o bloqueos de API.
- Instala skills oficiales únicamente desde sus repositorios oficiales; revisa comandos antes de ejecutarlos.
- Esta v0.2 está en **evaluación experimental**: el pipeline de nuevo motor debe probarse realmente con internet/npm en una sesión limpia de Codex antes de declararlo funcional comercialmente.

## ACTUALIZACIÓN v0.3 · NUEVOS PACKS

La versión actual es **v0.3**. Lee `docs/STYLE_SELECTION.md`, `docs/THIRD_PARTY_STYLE_PACKS.md` y `.agents/skills/style-pack-director/SKILL.md` antes de trabajar con estilos avanzados.

- Ejecuta `python scripts/style_packs.py doctor` y `python scripts/style_packs.py list` para descubrir herramientas reales. Para revisar acciones antes de descargar usa `python scripts/style_packs.py install --pack all` (simulación). Solo instala tras consentimiento con `python scripts/style_packs.py install --pack all --execute`. En terceros, `--with-deps` ejecuta instaladores de sus repositorios y requiere revisión específica.
- **Lemo-Opuscar**: lee `vendor/lemo-opuscar/styles/<estilo>/STYLE.md`. Los 66 estilos anunciados son referencias del repositorio externo, NO implementaciones nativas certificadas en nuestro motor. Riesgo en Codex: creados para Claude Opus 5.5.
- **Claude Animation Base**: p5.js/p5.brush como proyecto aparte; estilos ilustrados artesanales. No confundas personaje de demo con una marca del cliente.
- **Paper Shaders**: demo opcional en `engines/remotion/src/paper-index.ts` mediante `npm run paper:render:demo` después de instalar el pack. Render WebGL pendiente de verificar.
- **HyperFrames**: CLI y core skills oficiales se instalan por `npx hyperframes skills update`; esto no sustituye validación de render.
- **Licencias**: solo el código propio viene en el ZIP; clones y paquetes terceros se obtienen de proveedores; respeta LICENSE/NOTICE y restricciones de audios de demos.
- Si usuario exige Remotion/HyperFrames/Lemo/p5 y no funciona, **informa del fallo**; no conviertas a legacy sin permiso.
