---
name: research-factcheck
description: Investiga y verifica hechos documentales o científicos antes de escribir guiones, y registra fuentes reales.
---

# research-factcheck

- Identifica afirmaciones comprobables, fechas, cifras y discrepancias.
- Consulta referencias primarias o institucionales mediante búsquedas disponibles, contrasta cuando sea posible.
- Escribe en `sources` URLs reales que hayas consultado, nunca inventadas.
- Separa hechos de hipótesis, dramatizaciones, metáforas y diagramas esquemáticos.
- Si no puedes acceder a fuentes externas, explica la limitación y solicita validación factual antes de publicar.
- Para la Luna: rotación sincrónica no equivale a ausencia de rotación ni a cara permanentemente oscura.
