---
name: animation-map
description: Genera mapas esquemáticos con puntos y líneas animadas para explicar rutas abstractas.
---

# animation-map

- `style: map`, `headline`, `narration`, `points`: coordenadas [[x,y],...] normalizadas de 0 a 1.
- Es un diagrama de recorrido ilustrativo; NO genera mapas cartográficos reales, fronteras ni latitud/longitud.
- Si se requiere mapa real geográfico, no inventes coordenadas: marca el límite de v0.1 o prepara asset cartográfico licenciado.
- Mantén puntos dentro del lienzo y rutas cortas.
