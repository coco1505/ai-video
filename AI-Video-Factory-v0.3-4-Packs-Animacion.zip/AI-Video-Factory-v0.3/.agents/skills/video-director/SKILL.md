---
name: video-director
description: Dirige el proceso completo desde un prompt hasta un MP4; úsala cada vez que pidan crear un video, reel, Short o documental.
---

# video-director

1. Lee `AGENTS.md`, `docs/SCHEMA.md` y ejecuta diagnóstico/setup.
2. Extrae tema, audiencia, duración y estilo. Si faltan, decide valores seguros y explica brevemente.
3. Investiga, redacta guion original, define beats, crea `projects/<slug>.json`.
4. Activa las skills de animación según el tipo de escena. Usa 4–10 escenas para 30–60 segundos.
5. Renderiza con `scripts/make_video.py`, revisa QC y contact sheet, corrige.
6. Entrega MP4 real con nombres de archivos y fallos/limitaciones concretas. No te limites a escribir prompts.
**Contrato**: no reescribir renderer para cada video; producir proyecto JSON válido.
