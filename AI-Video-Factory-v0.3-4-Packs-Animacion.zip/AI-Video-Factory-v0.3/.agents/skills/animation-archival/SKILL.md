---
name: animation-archival
description: Crea estética de archivo histórico con imagen autorizada o recurso sepia procedural.
---

# animation-archival

- `style: archival`, `headline`, `narration`.
- Para datos históricos específicos, usa un recurso verificado y con licencia: `asset`, `source_url`, `license`.
- Si falta recurso visual, el renderer dibuja una tarjeta sepia ficticia: identifícala como ilustración, no documento real.
- Evita fabricar falsos materiales históricos cuando el video lo presente como evidencia.
- Usa esta skill al explicar pasado, no como sustituto de prueba documental.
