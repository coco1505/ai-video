---
name: visual-router
description: Elige automáticamente el estilo de animación más informativo para cada escena y evita efectos superfluos.
---

# visual-router

- Hook/punchline -> kinetic.
- Sincronía Tierra/Luna -> science (componente astronómico especializado; no aplicarlo a cualquier proceso científico).
- Comparar datos -> infographic con `stats` reales.
- Evolución histórica -> timeline con `events`.
- Contexto con foto autorizada -> cinematic o archival y asset/licencia.
- Conexiones editoriales -> collage.
- Ruta ilustrativa de puntos abstractos -> map con `points` normalizados; no simules geografía exacta.
- Mezcla estilos cuando mejore la comprensión; si el usuario pide uno, respétalo salvo incompatibilidades fácticas.
