---
name: animation-collage
description: Compone collage editorial animado con paneles y titulares en documental o ensayo.
---

# animation-collage

- `style: collage`; por ahora genera tres tarjetas visuales abstractas con entradas escalonadas y un título.
- Estética útil para conectar ideas y contrastar conceptos. No es un motor de montaje fotográfico automático en v0.1.
- Para exigir fotografías distintas por panel, señalar como capacidad futura; no afirmar soporte no implementado.
- Mantén `headline` conciso y narración que conecte las piezas.
