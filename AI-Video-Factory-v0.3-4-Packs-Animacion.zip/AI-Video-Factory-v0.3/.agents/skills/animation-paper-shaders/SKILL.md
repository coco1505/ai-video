---
name: animation-paper-shaders
description: Usa Paper Shaders para fondos gráficos deterministas con Remotion y WebGL.
---

# Paper Shaders en Remotion

- Fuente `https://github.com/paper-design/shaders`; paquetes npm `@paper-design/shaders` (vanilla) y `@paper-design/shaders-react` (React).
- Ejecuta `python scripts/style_packs.py install --pack paper-shaders --execute` para añadir versiones exactas al package.json local.
- Demo React real: `engines/remotion/src/paper-index.ts`, composición `PaperShaderIntro`; ver `docs/SHADERS.md`.
- IMPORTANTE: una animación WebGL que avanza con el reloj del navegador puede romper el render fotograma-a-fotograma. Mantener `speed={0}` y animar el contenedor desde `useCurrentFrame` con Remotion; cada fotograma debe reproducirse igual en renders repetidos.
- Revisar disponibilidad GPU/WebGL/headless Chrome; si falla usar fondos SVG/CSS del motor Remotion principal.
- Mantener contraste entre shader, texto y captions; limitar distracciones y proteger safe zones.
- Apache 2.0: conservar LICENSE y NOTICE cuando se redistribuya código de la librería.
