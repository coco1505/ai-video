---
name: asset-licensing
description: Comprueba derechos de fotos, footage, audio y stock; mantiene manifiesto antes de exportación.
---

# asset-licensing

- Toda `scene.asset` debe ser ruta local relativa al JSON, tener `source_url` y `license` comprobadas.
- No incluyas/revendas paquetes stock descargados dentro del ZIP sin permiso explícito de redistribución.
- No infieras licencia de materiales encontrados en redes sociales, películas, museos o NASA sin revisar términos aplicables.
- Prefiere assets propios/usuario o con permisos claros; incluye creador si se conoce.
- El renderer registra `asset-manifest.json`, pero la auditoría legal humana sigue siendo necesaria.
