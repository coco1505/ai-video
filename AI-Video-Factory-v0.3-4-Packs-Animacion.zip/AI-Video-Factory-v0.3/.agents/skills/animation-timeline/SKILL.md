---
name: animation-timeline
description: Construye líneas temporales animadas con fechas y eventos históricos.
---

# animation-timeline

- `style: timeline`; `events`: lista de 2 a 4 `{year,label}`.
- Orden cronológico real; no inventar fechas; la línea va revelando eventos.
- Cada etiqueta debe ser corta para mantener legibilidad en móvil.
- Si hay más de cuatro hitos, dividir en varias escenas o sintetizar.
- Narración debe explicar causas y consecuencias, no leer todas las fechas sin contexto.
