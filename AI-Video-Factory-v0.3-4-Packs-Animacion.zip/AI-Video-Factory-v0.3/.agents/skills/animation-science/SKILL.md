---
name: animation-science
description: Genera diagrama didáctico de rotación sincrónica Tierra-Luna con movimiento orbital.
---

# animation-science

- `style: science` renderiza por código una Tierra central y una Luna orbitando; marcador amarillo del hemisferio lunar apunta a Tierra.
- Componentes especiales `headline` y `subhead`; por defecto "ROTACIÓN SINCRÓNICA".
- Etiqueta siempre el diagrama como esquemático/no a escala (el renderer lo muestra automáticamente).
- La rotación lunar es simultánea a la órbita; evita animar la Luna manteniendo una orientación fija respecto a un observador externo.
- No uses esta animación para ciencia no relacionada con el sistema Tierra-Luna. Añadiremos librería científica general futura.
