---
name: animation-infographic
description: Visualiza cifras, comparaciones y datos en tarjetas y barras animadas.
---

# animation-infographic

- `style: infographic`; usa `headline` y `stats` de 2–3 items `{label,value}`.
- Solo incluir cifras contrastadas con `sources`. Evita precisión fingida y escalas incorrectas.
- La barra es decorativa/progresiva en v0.1, NO corresponde automáticamente a una escala numérica.
- Mantén texto numérico corto para que no se recorte; si necesitas gráfico a escala, marcar limitación y desarrollar extensión.
