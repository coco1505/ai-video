---
name: animation-hyperframes-gsap
description: Animación de titulares, cards y números usando GSAP para HyperFrames.
---

# Choreografía con GSAP en HyperFrames

- Lee `engine-hyperframes/SKILL.md` y archivos HTML generados por `scripts/engines.py`.
- Usa secuencias por clips y un `gsap.timeline({paused:true})` con `fromTo` sobre opacity, transform, rotation y scale.
- Separa entrada (0.4–0.7 s), permanencia legible y salida (0.25–0.5 s); no sobreanimar texto ni repetir la misma transición 6 veces.
- Sin `setTimeout`, `requestAnimationFrame`, aleatoriedad no sembrada ni bucles infinitos. HyperFrames controla el tiempo por fotograma.
- Antes de entregar ejecuta `lint`, `check`, `snapshot` y `render`; si falla alguno, corrige o comunica la limitación.
- En HTML generado hay estilos `kinetic`, `science`, `infographic`, `timeline` y marcadores gráficos para otros estilos, con espacio para extender.
