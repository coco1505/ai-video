---
name: animation-handpainted-p5
description: Crea animación ilustrada a mano con p5.js/p5.brush a partir de Claude Animation Base.
---

# Animación pintada a mano (p5.js + p5.brush)

- Proyecto: `https://github.com/JohnHeibel/ClaudeAnimationBase`.
- Instalar opcional: `python scripts/style_packs.py install --pack claude-animation-base --execute` y si autoriza dependencias del repositorio `--with-deps`.
- Guía: `vendor/claude-animation-base/ANIMATION_GUIDE.md`; dibujo en p5.js + p5.brush, render vía Puppeteer/FFmpeg según su proyecto. Puede necesitar navegador compatible.
- Conservar la estética pero crear un personaje original para el usuario; no usar automáticamente el personaje Clawd como marca propia.
- El usuario pide «acuarela», «dibujado a mano», «cartoon artesanal»: elegir este modo, proponer una prueba de fotogramas antes de un render completo.
- Validar consistencia de personajes, paleta, manos, expresiones, interpolación, tiempos y salida MP4. NO hay puente automático completo con `scripts/engines.py` en v0.3.
