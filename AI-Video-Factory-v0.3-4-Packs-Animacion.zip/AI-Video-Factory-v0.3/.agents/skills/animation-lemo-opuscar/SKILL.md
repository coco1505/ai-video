---
name: animation-lemo-opuscar
description: Busca y aplica estilos de Lemo-Opuscar con un archivo STYLE.md verificable y limita promesas en Codex.
---

# Estilos de Lemo-Opuscar (fuente externa, experimental)

- Fuente: `https://github.com/lemomo-ai/lemo-opuscar` (66 estilos anunciados en README, 2026-11-08).
- `python scripts/style_packs.py install --pack lemo-opuscar --execute` descarga el repositorio a `vendor/lemo-opuscar/` y copia la skill oficial a `.agents/skills` / `.claude/skills` cuando existe.
- Lee `vendor/lemo-opuscar/AGENTS.md`, `DIRECTOR.md`, `TECHNIQUE.md` y `styles/<elegido>/STYLE.md` antes de intentar la producción. `python scripts/style_packs.py catalog` descubre estilos reales.
- El autor recomienda Claude Opus 5.5. En Codex, tratar como experimental: crear una prueba corta de 5–10 s y evaluar resultados antes de render largo.
- El motor de Lemo es distinto de Remotion/HyperFrames; **no afirmar** que este kit ya produce cualquier `STYLE.md` usando `scripts/engines.py`. El agente debe seguir el pipeline de Lemo para el estilo solicitado y validar el MP4.
- El código/documentación original tienen MIT; demostraciones CC BY 4.0 con exclusiones en voces y assets. No empaquetar demos para reventa sin revisión.
