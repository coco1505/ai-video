---
name: style-pack-director
description: Selecciona entre Remotion, HyperFrames, Lemo-Opuscar, p5 y shaders sin prometer capacidades no verificadas.
---

# Director de packs y estilos

1. Si el usuario pide estilo concreto, respeta su elección. Abre `docs/THIRD_PARTY_STYLE_PACKS.md` y consulta `python scripts/style_packs.py list`.
2. Para diagramas, subtítulos y montaje continuo: Remotion. Para HTML/GSAP: HyperFrames. Para un look de las 66 referencias de estilo: Lemo-Opuscar como **biblioteca experimental**, con estilo concreto elegido por `STYLE.md`. Para ilustración a mano: Claude Animation Base / p5.brush. Para fondos/gradientes: Paper Shaders.
3. No declares que 66 estilos Lemo funcionan en Codex: el autor los optimizó para Claude Opus 5.5.
4. Antes de ejecutar instaladores externos, presentar los comandos, confirmar autorización de usuario y revisar scripts. `python scripts/style_packs.py install --pack all` solo simula; `--execute` descarga realmente.
5. Una referencia visual no equivale a un render. Valida MP4 con ffprobe, duración, fotogramas y legibilidad.
6. Para comprar/vender, los vídeos de demostración y voces ajenas NO están incorporados automáticamente a nuestro producto. Respetar créditos/licencias.
