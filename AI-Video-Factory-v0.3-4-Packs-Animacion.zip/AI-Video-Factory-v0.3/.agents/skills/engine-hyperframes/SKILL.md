---
name: engine-hyperframes
description: Autoría de escenas HTML GSAP con HyperFrames.
---

# HyperFrames oficial (HeyGen)

**Cuándo:** kinetic type, reveals de datos, efectos y motion graphics basados en HTML/GSAP, especialmente piezas cortas.

1. Instala skills oficiales por `python scripts/engines.py install --skills --agent codex` cuando haya internet. Es la fuente `heygen-com/hyperframes`. También existen skills de HyperFrames fuera de este repo para auditar movimiento y usar catálogos.
2. Genera el video a partir de `project.json` mediante `python scripts/engines.py generate --engine hyperframes --project projects/moon_demo.json --voice none --out output/hyperframes-luna/`.
3. En el directorio impreso por el generador: `npx --yes hyperframes lint`, `npx --yes hyperframes check --json`, `npx --yes hyperframes snapshot` y `npx --yes hyperframes render --quality looks --output master.mp4`.
4. Render directo: `python scripts/engines.py render --engine hyperframes --project projects/moon_demo.json --voice auto --out output/luna-hyperframes.mp4`.

**Contratos esenciales:** HTML con `data-composition-id="root"`, dimensiones y duración explícitas; clips con `class="clip"`, `data-start`, `data-duration`, `data-track-index`; GSAP `timeline({paused:true})` y registro de `window.__timelines.root`. Usar tiempos absolutos y valores deterministas. Animaciones y voces de bajo nivel deben comprobarse con el CLI de HyperFrames; una página HTML que abre no es evidencia suficiente de render.

NO afirmar que el motor o skills oficiales vienen embebidos: se descargan en la primera instalación con red.
