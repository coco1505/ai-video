---
name: captions-safezone
description: Produce subtítulos sincronizados y legibles para Shorts, Reels y TikTok.
---

# captions-safezone

- El renderer incorpora subtítulos quemados y `captions.srt` en grupos de hasta ~4 palabras.
- En ElevenLabs `alignment` suministra tiempos por carácter; en espeak son estimados.
- Posición prevista ~70–79% del alto, fuera del extremo inferior de interfaz móvil.
- Revisa contact sheet y render para cortes de palabras, solapamientos y contraste.
- Evita subtítulos redundantes sobre el titular principal: si lo ves en preview, pide corrección en siguiente fase.
