---
name: storyboard
description: Traduce guion a escenas estructuradas JSON para el renderer y asigna estilos y recursos por beat.
---

# storyboard

- Lee `docs/SCHEMA.md` y `projects/moon_demo.json`.
- Una escena = una idea. Cada escena incluye `style`, `headline` y `narration`.
- Reparte la complejidad: cifras -> infographic; causalidad lunar -> science; fechas -> timeline; hook -> kinetic; narración cinematográfica -> cinematic.
- Prefiere 4–10 escenas para videos breves. La duración real será la voz; escribe guion acorde (aprox. 120–160 palabras/minuto según voz).
- No uses `asset` sin `license` y `source_url`; no infieras que la biblioteca proporciona video stock automáticamente.
- Valida JSON con el doctor y render; corrige si falla.
