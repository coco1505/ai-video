---
name: animation-cinematic
description: Crea documental cinematográfico con pan/zoom de imagen autorizada y encabezados editorializados.
---

# animation-cinematic

- `style: cinematic`, `headline`, `subhead`, `narration`.
- Mejor resultado: `asset` JPEG/PNG relativo al JSON, con `source_url`,`license`, `creator`.
- Sin imagen, el renderer muestra una Luna PROCEDURAL (placeholder) y NO metraje real.
- Voz dirige ritmo; la cámara hace zoom sutil para no distraer. No cambiar a un clip generativo sin autorización de coste.
- No presentar placeholders como imágenes NASA o fotografías auténticas.
