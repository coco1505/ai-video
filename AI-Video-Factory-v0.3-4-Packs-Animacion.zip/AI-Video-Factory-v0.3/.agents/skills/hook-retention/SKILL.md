---
name: hook-retention
description: Optimiza el hook, estructura, claridad y retención de videos cortos divulgativos; úsala al escribir y revisar.
---

# hook-retention

- Produce internamente 3 hooks: pregunta paradójica, afirmación contraintuitiva y dato visual; elige el más preciso y claro.
- Primer fotograma con contenido legible. No fundido desde negro ni logo de 3 segundos.
- Plantea promesa de aprendizaje rápidamente y respóndela en el centro/final.
- Cada escena debe añadir información útil; cambia visual al cambiar idea, no por reloj fijo.
- Subtítulos legibles y alineados a voz; cierre con un dato que recontextualice, no CTA largo.
- Registra ideas de experimentos A/B; no prometas viralidad ni extrapoles datos publicitarios a orgánico.
