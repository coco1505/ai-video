---
name: engine-router
description: Elige motor Remotion/HyperFrames/legacy según cada solicitud.
---

# Director de motores

**Usar ante cualquier petición de video.** Primero leer AGENTS.md y decidir el motor basándote en el pedido y los recursos disponibles.

- `remotion`: narrativa de 20 a 90 segundos, múltiples escenas, voz, captions, SVG, gráficos, timeline, export MP4. Motor React en `engines/remotion/src/`.
- `hyperframes`: motion graphics HTML/GSAP, reels de títulos, transiciones, overlays, efectos y visuales por clip. Productor `scripts/engines.py` genera HTML compatible.
- `legacy`: opción estable probada y más ligera: `python scripts/make_video.py` (Pillow + FFmpeg); NO elegirla de forma silenciosa cuando el usuario pide explícitamente Remotion o HyperFrames.

**Elige un motor por render**: si una escena necesita otro motor, exporta la escena a un clip MP4 y luego compón mediante FFmpeg en una iteración futura. No asegures que existe un compositor híbrido automático completo en esta versión.

Paso inicial: `python scripts/engines.py doctor`. Si falta Node >=22, ffmpeg o deps npm, instala con consentimiento. Para Remotion: `python scripts/engines.py install --skills --agent codex`. Para HyperFrames, la CLI se ejecuta por `npx hyperframes` y descargará su implementación oficial cuando haya internet.

**Entrega**: MP4 verificado por ffprobe, fuentes, limitaciones reales, sin gastar créditos sin permiso.
