---
name: quality-control
description: Valida el MP4, subtítulos, audio, integridad de archivo y limitaciones antes de entregar.
---

# quality-control

- Comprueba que el archivo `master.mp4` existe, pesa más de cero y `qc-report.json.pass=true`.
- Abre o revisa `contact-sheet.png` y varios frames si hay herramientas visuales; los tests actuales son técnicos, NO revisión estética automatizada.
- Revisa SRT, manifest de licencias, fuentes, voz real o demo y duración.
- Si falló FFmpeg, abre `ffmpeg-error.log`, corrige causas y re-renderiza.
- No afirmar que se ha logrado QC visual, de retención o fidelidad científica si no se verificó.
- No entregar el render con un problema conocido sin advertirlo.
