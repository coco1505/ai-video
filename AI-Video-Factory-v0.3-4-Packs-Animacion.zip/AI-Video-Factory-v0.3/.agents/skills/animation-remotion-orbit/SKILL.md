---
name: animation-remotion-orbit
description: Animación científica de órbitas SVG con Remotion.
---

# Órbitas, rotación y explicación científica

Código real: `engines/remotion/src/film.tsx`, componentes `OrbitalDiagram`, `Moon`.

Para explicar la rotación síncrona, muestra Tierra estable, trayectoria lunar y marca visible sobre la Luna. Usa un progreso continuo y una relación temporal explícita: una rotación propia por órbita sideral. Etiqueta "esquema, no a escala" si añades distancias o tamaños. Mantén el hook visible desde 0:00 y los textos en zonas seguras. Evita confundir cara oculta con cara sin luz; busca fuentes verificadas.

Si se requiere geometría espacial verdaderamente 3D, no afirmar que este SVG lo es. En versiones posteriores, integrar Three.js para cámaras y volúmenes.
