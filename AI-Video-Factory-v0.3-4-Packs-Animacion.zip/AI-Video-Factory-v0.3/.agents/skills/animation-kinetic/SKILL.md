---
name: animation-kinetic
description: Crea titulares y tipografía cinética para ganchos, preguntas o conclusiones usando estilo kinetic.
---

# animation-kinetic

- Usa `style: kinetic`, `headline` de hasta ~5 palabras y `eyebrow` corto.
- En v0.1 el renderer ejecuta entrada lateral de panel, aparición del texto y subrayado animado.
- Mantén contraste, prioridad visual a una sola frase y evitar texto duplicado de captions.
- Úsala en los primeros segundos o en conclusiones; no la uses para explicar órbitas ni datos complejos.
- Ajusta `headline` en JSON; no edites `src/video_factory/visual.py` por video.
