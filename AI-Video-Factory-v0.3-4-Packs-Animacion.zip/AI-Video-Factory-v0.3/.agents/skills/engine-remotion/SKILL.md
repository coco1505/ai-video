---
name: engine-remotion
description: Autoría y render de videos React SVG con Remotion.
---

# Remotion para videos narrativos

**Cuándo:** infografías, ciencia, timelines, documentales narrados y efectos React sincronizados.

1. Revisa `engines/remotion/src/film.tsx` y `root.tsx`; no inventes componentes.
2. Instala paquetes desde npm mediante `python scripts/engines.py install`. El paquete se fija exactamente en `package.json`.
3. Para skills oficiales usa `python scripts/engines.py install --skills --agent codex`, que descarga instrucciones desde `remotion-dev/skills`. Estas no están vendorizadas.
4. Genera `projects/video.json` conforme a `docs/SCHEMA.md`.
5. Render: `python scripts/engines.py render --engine remotion --project projects/video.json --voice auto --out output/video-remotion.mp4`.
6. Controla los títulos y subtítulos con márgenes seguros. Revisa fotogramas y reitera. Para un preview: `npm run remotion:studio`.

**Técnico:** `Sequence`, `spring`, `interpolate`, SVG de órbitas y cards, `calculateMetadata` según tiempos reales de narración, `<Audio>` y subtítulos cronometrados. `--voice none` produce prueba visual sin audio; nunca presentarla como documental narrado profesional.

**Licencia:** Remotion tiene licencia propietaria con condiciones de uso comercial según tamaño del equipo y automatizaciones. No venderlo como open source, no vender copias del motor. Consulta `docs/LICENSING.md`.
