---
name: voice-elevenlabs
description: Genera narración con ElevenLabs y sincronización de palabras, o voz local demo si no hay API.
---

# voice-elevenlabs

- Verifica `.env` con `ELEVENLABS_API_KEY`, `ELEVENLABS_VOICE_ID`, `ELEVENLABS_MODEL_ID`; nunca publiques la clave.
- `scripts/make_video.py --voice auto` activa ElevenLabs si hay clave; ruta oficial `POST /v1/text-to-speech/{id}/with-timestamps`.
- Si no hay clave y espeak está instalado, puedes hacer `--voice espeak` sólo como demo robótica.
- No consumir créditos de ElevenLabs sin autorización del usuario y sin informar costos variables.
- Conserva el audio y `captions.srt`; si falla API, informa error, no inventes narración.
- Alineación real se usa cuando API devuelve tiempos y texto coincidente.
