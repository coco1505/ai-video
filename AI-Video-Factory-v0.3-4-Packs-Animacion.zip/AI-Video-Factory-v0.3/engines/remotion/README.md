# Motor Remotion

Crea motion graphics con React, SVG y animación dirigida por fotogramas. Los estilos `kinetic`, `science`, `infographic`, `timeline`, `cinematic`, `archival`, `collage`, `map` tienen representaciones iniciales y el agente puede ampliar los componentes.

```bash
npm install --no-audit --no-fund
npm run remotion:studio
python scripts/engines.py render --engine remotion --project projects/moon_demo.json --voice auto --out output/moon_remotion.mp4
```

El render requiere Node 22+, dependencias npm ya instaladas y navegador Chromium (Remotion lo gestiona). `--voice auto` usa ElevenLabs si está configurado o la voz local de demostración. Se solicita confirmación antes de consumir créditos en un flujo con agente.

El ejemplo de Studio no lleva voz salvo que se pasen props. `engines.py render` genera y sincroniza el audio y las props desde `project.json`. Las escenas científicas son esquemáticas. No se obtienen imágenes ni metraje automáticamente.
