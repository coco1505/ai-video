import {registerRoot} from 'remotion';
import {PaperRoot} from './paper-root';
registerRoot(PaperRoot);
