import React from 'react';
import {Composition} from 'remotion';
import {PaperShaderIntro} from './paper-film';
export const PaperRoot: React.FC = () => <Composition id="PaperShaderIntro" component={PaperShaderIntro}
  durationInFrames={180} fps={30} width={720} height={1280}
  defaultProps={{title:'LA LUNA Y SUS MISTERIOS',subtitle:'Fondo Paper Shaders · animación Remotion'}} />;
