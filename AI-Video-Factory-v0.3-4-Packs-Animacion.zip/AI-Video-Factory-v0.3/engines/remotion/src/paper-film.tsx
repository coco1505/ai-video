import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import {MeshGradient} from '@paper-design/shaders-react';

// Esta composición es opcional, separada del index.ts normal para NO romper
// el motor principal cuando @paper-design/shaders-react no esté instalado.
// El shader permanece estático (speed=0); Remotion mueve su contenedor por frame.
export const PaperShaderIntro: React.FC<{title?:string;subtitle?:string}> = ({
  title='EL UNIVERSO EN MOVIMIENTO',subtitle='AI Video Factory · Remotion + Paper Shaders',
}) => {
  const frame=useCurrentFrame();
  const {width,height}=useVideoConfig();
  const entrance=interpolate(frame,[0,24],[45,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
  const opacity=interpolate(frame,[0,18],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
  const shift=interpolate(frame,[0,150],[-30,30],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
  return <AbsoluteFill style={{background:'#0e1026',overflow:'hidden',fontFamily:'Arial, sans-serif'}}>
    <div style={{position:'absolute',inset:-50,transform:`scale(1.12) translateX(${shift}px)`}}>
      <MeshGradient colors={['#0d0b22','#7d30e9','#0dc8bf','#e95caa']} distortion={0.9} swirl={0.4} speed={0}
        style={{width:'100%',height:'100%'}}/>
    </div>
    <AbsoluteFill style={{background:'linear-gradient(to bottom, #06061544 10%, #060615aa 100%)'}}/>
    <div style={{position:'absolute',top:height*0.38,left:width*.1,width:width*.8,
      transform:`translateY(${entrance}px)`,opacity,color:'#fff',textAlign:'center'}}>
      <div style={{fontSize:width*.075,letterSpacing:-1,fontWeight:900,lineHeight:1.05,textShadow:'0 8px 32px #000'}}>{title}</div>
      <div style={{fontSize:width*.037,marginTop:24,lineHeight:1.3,color:'#f4e8ff'}}>{subtitle}</div>
    </div>
    <div style={{position:'absolute',bottom:height*.11,left:'12%',right:'12%',height:3,background:'#ffffffa6'}}/>
  </AbsoluteFill>;
};
