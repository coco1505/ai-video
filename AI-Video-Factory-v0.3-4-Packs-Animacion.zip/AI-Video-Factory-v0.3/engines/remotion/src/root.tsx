import React from 'react';
import {Composition} from 'remotion';
import {Film, FilmProps, demoProps} from './film';

const totalFrames = (p: FilmProps) => {
  const duration = p.scenes.reduce((maximum, scene) => Math.max(maximum, scene.end), 0);
  return Math.max(1, Math.ceil(duration * p.fps));
};

export const RemotionRoot: React.FC = () => (
  <Composition
    id="LunaExplicada"
    component={Film}
    fps={30}
    width={720}
    height={1280}
    durationInFrames={30 * 36}
    defaultProps={demoProps}
    calculateMetadata={({props}) => {
      const p = props as FilmProps;
      return {
        fps: p.fps,
        width: p.width,
        height: p.height,
        durationInFrames: totalFrames(p),
      };
    }}
  />
);
