import React from 'react';
import {AbsoluteFill, Audio, Sequence, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';

export type Scene = {
  style: 'kinetic'|'science'|'infographic'|'timeline'|'cinematic'|'archival'|'collage'|'map'|string;
  headline: string;
  subhead?: string;
  eyebrow?: string;
  narration?: string;
  start: number;
  end: number;
  stats?: {label: string; value: string}[];
  events?: {year: string; label: string}[];
};
export type Caption = {text: string; start: number; end: number};
export type FilmProps = {title: string; width: number; height: number; fps: number; scenes: Scene[]; captions?: Caption[]; audioSrc?: string | null};

export const demoProps: FilmProps = {
  title: '¿Por qué la Luna siempre muestra la misma cara?', width: 720, height: 1280, fps: 30,
  scenes: [
    {style:'kinetic', headline:'¿LA LUNA NO GIRA?', subhead:'La respuesta sorprende', start:0, end:6},
    {style:'science', headline:'SÍ GIRA', subhead:'Una vuelta por cada órbita', start:6,end:13},
    {style:'infographic', headline:'DOS CICLOS, UN RITMO',stats:[{label:'ROTACIÓN',value:'27,3 días'},{label:'ÓRBITA',value:'27,3 días'}],start:13,end:20},
    {style:'cinematic', headline:'ROTACIÓN SINCRÓNICA',subhead:'Por eso vemos casi siempre el mismo hemisferio.',start:20,end:29},
    {style:'kinetic',headline:'LA CARA OCULTA TAMBIÉN RECIBE LUZ',start:29,end:36},
  ]
};

const BG = '#080f21';
const WHITE = '#ecf4ff';
const CYAN = '#5ee1fa';
const AMBER = '#ffd184';
const clamp = (v:number) => Math.max(0, Math.min(1, v));
const fade = (f:number, duration:number) => {
  const fadeIn = clamp(f / 12);
  const fadeOut = clamp((duration - f) / 10);
  return Math.min(fadeIn, fadeOut);
};
const Moon: React.FC<{size:number; highlighted?:boolean}> = ({size, highlighted}) => (
  <svg viewBox="0 0 400 400" width={size} height={size} style={{overflow:'visible',filter:'drop-shadow(0 0 25px #9fdafa22)'}}>
    <defs>
      <radialGradient id="moonShade" cx="32%" cy="27%" r="78%">
        <stop offset="0%" stopColor="#f5f8f6"/><stop offset="54%" stopColor="#bac7cf"/><stop offset="100%" stopColor="#465b75"/>
      </radialGradient>
    </defs>
    <circle cx="200" cy="200" r="188" fill="url(#moonShade)"/>
    <circle cx="120" cy="134" r="45" fill="#697b8b" opacity="0.28"/>
    <circle cx="247" cy="230" r="62" fill="#667689" opacity="0.21"/>
    <circle cx="305" cy="118" r="29" fill="#60738b" opacity="0.22"/>
    <circle cx="155" cy="294" r="27" fill="#677c8c" opacity="0.2"/>
    {highlighted && <circle cx="200" cy="200" r="183" fill="none" stroke={CYAN} strokeWidth="8"/>}
  </svg>
);
const OrbitalDiagram: React.FC<{frame:number;fps:number}> = ({frame,fps}) => {
  const a = frame/fps*0.65;
  const x = 360 + Math.cos(a) * 185;
  const y = 315 + Math.sin(a) * 115;
  return <div style={{position:'relative', width:'100%',height:680}}>
    <svg viewBox="0 0 720 680" width="100%" height="100%">
      <ellipse cx="360" cy="315" rx="185" ry="115" fill="none" stroke="#88baf577" strokeWidth="3" strokeDasharray="12 13"/>
      <circle cx="360" cy="315" r="98" fill="#2878c8"/>
      <path d="M 305 253 Q 351 210 385 254 Q 400 315 355 324 L 326 384 Q 269 342 305 253" fill="#3fbfa4" opacity="0.85"/>
      <circle cx={x} cy={y} r="48" fill="#c6d4df" stroke="#f0f5f8" strokeWidth="3"/>
      <circle cx={x+18*Math.cos(a)} cy={y+18*Math.sin(a)} r="8" fill="#3f5064"/>
      <path d={`M360,315 L${x},${y}`} stroke={CYAN} strokeWidth="2" strokeDasharray="7 9"/>
      <text x="360" y="455" fill={WHITE} fontSize="28" textAnchor="middle">TIERRA</text>
    </svg>
  </div>;
};
const SceneCard: React.FC<{scene:Scene;durationFrames:number}> = ({scene,durationFrames}) => {
  const frame=useCurrentFrame();
  const {fps,width,height}=useVideoConfig();
  const entrance=spring({fps,frame,config:{damping:16,stiffness:105}});
  const opacity=fade(frame,durationFrames);
  const style=scene.style;
  const moveY=interpolate(entrance,[0,1],[75,0]);
  const heroY=height*0.39;
  const fontSize=Math.max(36, Math.min(70,width*0.075));
  return <AbsoluteFill style={{background:BG,color:WHITE,overflow:'hidden',fontFamily:'Arial, sans-serif',opacity}}>
    <div style={{position:'absolute',top:-200,left:-240,width:900,height:800,background:'radial-gradient(circle,#214d8655,transparent 68%)'}}/>
    <div style={{position:'absolute',top:width*0.13,left:width*0.085,letterSpacing:5,color:CYAN,fontSize:20,fontWeight:800}}>{scene.eyebrow || (style==='science'?'CIENCIA EN MOVIMIENTO':style.toUpperCase())}</div>
    {style==='science' || style==='map' ? <div style={{position:'absolute',top:height*0.2,width:'100%'}}><OrbitalDiagram frame={frame} fps={fps}/></div> : null}
    {style==='cinematic' || style==='archival' || style==='collage' ? <div style={{position:'absolute',top:height*0.24,left:'50%',transform:`translateX(-50%) scale(${1 + frame/Math.max(1,durationFrames)*0.15})`,opacity:0.85}}><Moon size={width*0.72}/></div> : null}
    {style==='infographic' ? <div style={{position:'absolute',top:height*0.28,width:'100%',display:'flex',justifyContent:'space-evenly'}}>{(scene.stats||[]).slice(0,3).map((s,i)=><div key={i} style={{border:`2px solid ${CYAN}`,background:'#10223b',borderRadius:24,padding:22,transform:`scale(${interpolate(frame,[i*5,i*5+18],[0.75,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})})`,textAlign:'center'}}><div style={{fontSize:21,color:CYAN}}>{s.label}</div><div style={{fontSize:36,fontWeight:900,marginTop:10}}>{s.value}</div></div>)}</div>:null}
    {style==='timeline' ? <div style={{position:'absolute',top:height*0.29,left:'9%',right:'9%'}}>{(scene.events||[]).slice(0,4).map((e,i)=><div key={i} style={{display:'flex',gap:20,alignItems:'center',marginBottom:30,opacity:clamp((frame-i*9)/15)}}><div style={{borderRadius:'50%',width:18,height:18,background:CYAN}}/><div><div style={{fontSize:22,color:AMBER}}>{e.year}</div><div style={{fontSize:29}}>{e.label}</div></div></div>)}</div>:null}
    {style==='kinetic' ? <div style={{position:'absolute',top:height*0.29,left:'12%',right:'12%',textAlign:'center',color:CYAN,fontSize:width*0.15,fontWeight:900,transform:`scale(${0.9+entrance*0.1})`}}>✦</div>:null}
    <div style={{position:'absolute',top:heroY + (style==='science'||style==='map'||style==='cinematic'||style==='archival'||style==='collage'?height*0.24:style==='kinetic'?height*0.13:height*0.11),left:'8%',right:'8%',transform:`translateY(${moveY}px)`,textAlign:'center'}}>
      <div style={{fontSize,fontWeight:900,letterSpacing:-1,lineHeight:1.08,textShadow:'0 8px 25px #001a34',overflowWrap:'break-word'}}>{scene.headline}</div>
      {scene.subhead && <div style={{fontSize:Math.max(24,width*.038),lineHeight:1.35,marginTop:22,color:'#bbd9ef'}}>{scene.subhead}</div>}
    </div>
    <div style={{position:'absolute',top:height*0.87,left:'9%',right:'9%',height:3,background:'#355578'}}/>
    <div style={{position:'absolute',top:height*0.87,left:'9%',height:3,width:`${clamp(frame/durationFrames)*82}%`,background:CYAN}}/>
  </AbsoluteFill>;
};
const Captions:React.FC<{captions:Caption[]}> = ({captions}) => {
  const frame=useCurrentFrame();
  const {fps,width,height}=useVideoConfig();
  const now=frame/fps;
  const text=captions.find((c)=>c.start<=now&&now<c.end)?.text;
  return text ? <div style={{position:'absolute',top:height*.78,left:'10%',width:'80%',textAlign:'center',background:'#071527bb',padding:'12px 18px',borderRadius:16,color:'#fff',fontFamily:'Arial,sans-serif',fontSize:width*.053,fontWeight:800,textShadow:'0 3px 6px #000'}}>{text}</div>:null;
};
export const Film:React.FC<FilmProps> = (props) => <AbsoluteFill style={{background:BG}}>
  {props.scenes.map((scene,i)=>{
    const from=Math.round(scene.start*props.fps);
    const to=Math.round(scene.end*props.fps);
    return <Sequence key={i} from={from} durationInFrames={Math.max(1,to-from)}>
      <SceneCard scene={scene} durationFrames={Math.max(1,to-from)}/>
    </Sequence>;
  })}
  {props.audioSrc ? <Audio src={staticFile(props.audioSrc)}/> : null}
  {props.captions&&props.captions.length>0 ? <Captions captions={props.captions}/> : null}
</AbsoluteFill>;
