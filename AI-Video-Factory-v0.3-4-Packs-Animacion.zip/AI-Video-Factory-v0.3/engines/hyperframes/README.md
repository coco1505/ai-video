# Motor HyperFrames

Genera composiciones HTML con clips cronometrados y una `gsap.timeline({paused:true})` registrada en `window.__timelines`. Requiere Node.js 22+, FFmpeg y el paquete oficial de HyperFrames que se descarga con npx al usarlo (no está incluido en el ZIP).

```bash
python scripts/engines.py generate --engine hyperframes --project projects/moon_demo.json --out output/hyperframes-moon
# En la carpeta output/hyperframes-moon:
npx --yes hyperframes lint
npx --yes hyperframes check --json
npx --yes hyperframes render --quality looks --output master.mp4
```

Para hacerlo en un paso: `python scripts/engines.py render --engine hyperframes --project projects/moon_demo.json --voice auto --out output/hyperframes-moon.mp4`.

Las skills oficiales se instalan desde `heygen-com/hyperframes` en la configuración inicial. Esta carpeta tiene un generador de composiciones propio y no redistribuye el código de HyperFrames.
