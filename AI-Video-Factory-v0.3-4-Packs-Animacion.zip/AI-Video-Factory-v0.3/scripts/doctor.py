#!/usr/bin/env python3
import importlib.util
import os
import shutil
import sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
print('AI Video Factory doctor | python',sys.version.split()[0])
env_path=root/'.env'
has_api=False
if env_path.exists():
    for line in env_path.read_text(encoding='utf-8').splitlines():
        if line.strip().startswith('ELEVENLABS_API_KEY=') and line.split('=',1)[1].strip():
            has_api=True
local_voice=bool(shutil.which('espeak') or shutil.which('espeak-ng') or
                 (sys.platform=='darwin' and shutil.which('say')) or
                 (os.name=='nt' and (shutil.which('powershell') or shutil.which('powershell.exe'))))
checks={'Python >=3.10':sys.version_info>=(3,10),
        'Pillow importable':importlib.util.find_spec('PIL') is not None,
        'ffmpeg':shutil.which('ffmpeg') is not None,
        'ffprobe':shutil.which('ffprobe') is not None,
        'local demo voice OR ElevenLabs configured':local_voice or has_api}
for name,ok in checks.items(): print(('OK  ' if ok else 'FAIL'),name)
if not all(checks.values()):
    print('Revisa README.md. Para voz ElevenLabs añade credenciales en .env.')
    sys.exit(1)
