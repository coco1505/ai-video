#!/usr/bin/env python3
"""Optional engine bridge. Legacy Pillow/FFmpeg remains in scripts/make_video.py."""
import argparse
import html
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from video_factory.project import load_project
from video_factory.voice import make_voice, probe_duration, read_env, scene_bounds, word_timings


def command_available(command):
    return shutil.which(command) is not None


def doctor():
    print('AI Video Factory v0.3 · Engine Doctor')
    for name in ('python', 'node', 'npm', 'ffmpeg', 'ffprobe', 'npx'):
        executable = 'python' if name == 'python' and command_available('python') else name
        print(f'{name:12} {shutil.which(executable) or "NO ENCONTRADO"}')
    if command_available('node'):
        version = subprocess.check_output(['node', '-p', 'process.versions.node'], text=True).strip()
        print('Node version:', version, '| HyperFrames OK' if int(version.split('.')[0]) >= 22 else '| REQUIERE NODE 22+')
    print('Remotion dependencies:', 'installed' if (ROOT / 'node_modules' / 'remotion').exists() else 'NOT installed (npm install)')
    print('HyperFrames CLI:', 'installable with npx (internet required); not bundled')
    print('Skills de proyecto:', len(list((ROOT / '.agents' / 'skills').glob('*/SKILL.md'))))
    return 0


def setup_engines(agent, skills=False):
    if not command_available('npm') or not command_available('node'):
        raise RuntimeError('Necesitas Node.js 22+ y npm antes de instalar los motores.')
    ver = subprocess.check_output(['node', '-p', 'process.versions.node'], text=True).strip()
    if int(ver.split('.')[0]) < 22:
        raise RuntimeError('HyperFrames necesita Node.js 22+. Versión detectada: ' + ver)
    subprocess.run(['npm', 'install', '--no-audit', '--no-fund'], cwd=ROOT, check=True)
    if skills:
        # Official publishers. Project-local install; do not use unverified forks.
        for repo in ('remotion-dev/skills', 'heygen-com/hyperframes'):
            subprocess.run(['npx', '--yes', 'skills@1.7.0', 'add', repo, '--agent', agent, '--yes'], cwd=ROOT, check=True)
    print('Motores preparados. Ejecuta: python scripts/engines.py doctor')


def safe_slug(text):
    slug = re.sub(r'[^a-zA-Z0-9_-]+', '-', text).strip('-').lower()
    return slug[:48] or 'video'


def prepare(project, voice, stage):
    stage.mkdir(parents=True, exist_ok=True)
    narration = '\n'.join(s['narration'].strip() for s in project['scenes'])
    read_env(ROOT)
    audio = None
    if voice != 'none':
        audio, align, source = make_voice(narration, stage, provider=voice)
        duration = probe_duration(audio) + .22
        timings = scene_bounds(project, narration, duration, align)
        words = word_timings(narration, duration, align)
        # Captions grouped at max 4 words, with timestamps derived from provider where possible.
        captions = []
        for index in range(0, len(words), 4):
            group = words[index:index + 4]
            captions.append({'text': ' '.join(w['text'] for w in group), 'start': group[0]['start'], 'end': group[-1]['end']})
        print('Narración:', source, f'({duration:.2f}s)')
    else:
        durations = [max(4, min(9, len(s['narration'].split()) / 2.4)) for s in project['scenes']]
        ends = [0.0]
        for d in durations:
            ends.append(ends[-1] + d)
        timings = list(zip(ends[:-1], ends[1:]))
        duration = ends[-1]
        captions = []
    scenes = []
    for s, (start, end) in zip(project['scenes'], timings):
        scene = {k: s[k] for k in ('style', 'headline', 'subhead', 'eyebrow', 'narration', 'stats', 'events') if k in s}
        scene.update(start=round(start, 3), end=round(end, 3))
        scenes.append(scene)
    return {'title': project.get('title', 'Video'), 'width': project['width'], 'height': project['height'],
            'fps': project['fps'], 'scenes': scenes, 'captions': captions, 'duration': duration}, audio


def generate_hyperframes(props, dest, audio=None):
    """Create a native HyperFrames HTML composition using its documented clip and GSAP contract."""
    dest = Path(dest)
    dest.mkdir(parents=True, exist_ok=True)
    if audio:
        (dest / 'assets').mkdir(exist_ok=True)
        suffix = Path(audio).suffix.lower()
        # Keep browser-friendly speech track. Prefer MP3 for HyperFrames media embedding.
        audio_target = dest / 'assets' / 'narration.mp3'
        subprocess.run(['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error', '-i', str(audio),
                        '-c:a', 'libmp3lame', '-q:a', '3', str(audio_target)], check=True)
    width, height = props['width'], props['height']
    dur = props['duration']
    sections = []
    animations = []
    for i, scene in enumerate(props['scenes']):
        start, end = scene['start'], scene['end']
        length = max(.1, end - start)
        headline = html.escape(scene['headline'])
        subhead = html.escape(scene.get('subhead', ''))
        eyebrow = html.escape(scene.get('eyebrow') or scene['style'].upper())
        safe_style = re.sub(r'[^a-zA-Z_-]', '', scene['style'])
        # Each single clip occupies track 0 for an exclusive interval.
        extra = ''
        if scene['style'] == 'science':
            extra = '<div class="orbit"><span class="earth">TIERRA</span><span class="moon"></span></div>'
        if scene['style'] == 'infographic':
            extra = '<div class="stats">' + ''.join(
                '<span class="stat">' + html.escape(x['label']) + '<strong>' + html.escape(x['value']) + '</strong></span>'
                for x in scene.get('stats', [])[:3]) + '</div>'
        if scene['style'] == 'timeline':
            extra = '<div class="events">' + ''.join('<p><b>' + html.escape(x['year']) + '</b> ' + html.escape(x['label']) + '</p>' for x in scene.get('events', [])[:4]) + '</div>'
        if scene['style'] in ('cinematic', 'archival', 'collage'):
            extra = '<div class="planet">☾</div>'
        if scene['style'] == 'map':
            extra = f'<svg class="route-map" viewBox="0 0 600 400"><path d="M80 270 L165 215 L290 240 L400 150 L525 80" fill="none" stroke="#153d5f" stroke-width="45" stroke-linecap="round"/><path id="route-{i}" d="M80 270 L165 215 L290 240 L400 150 L525 80" fill="none" stroke="#65ddf3" stroke-width="8" stroke-linecap="round" stroke-dasharray="1000" stroke-dashoffset="1000"/><circle cx="80" cy="270" r="14" fill="#ffde95"/><circle cx="525" cy="80" r="14" fill="#ffde95"/></svg>'
        sections.append(f'''<section id="scene-{i}" class="clip scene {safe_style}" data-start="{start:.3f}" data-duration="{length:.3f}" data-track-index="0">
  <div class="eyebrow">{eyebrow}</div>{extra}<div class="head" id="head-{i}">{headline}</div><div class="subhead">{subhead}</div>
</section>''')
        # Explicit absolute positions, deterministic seeking; no infinite animation.
        animations.append(f'tl.fromTo("#head-{i}", {{opacity:0,y:85,scale:0.94}}, {{opacity:1,y:0,scale:1,duration:0.65,ease:"power3.out"}}, {start:.3f});')
        animations.append(f'tl.fromTo("#scene-{i}", {{opacity:0}}, {{opacity:1,duration:0.30}}, {start:.3f});')
        if scene['style'] == 'science':
            animations.append(f'tl.fromTo("#scene-{i} .moon", {{x:0,y:0}}, {{x:-370,y:0,duration:{max(.6,length*.42):.3f},ease:"sine.inOut"}}, {start+.5:.3f});')
            animations.append(f'tl.to("#scene-{i} .moon", {{x:-185,y:155,duration:{max(.6,length*.38):.3f},ease:"sine.inOut"}}, {start+length*.5:.3f});')
        elif scene['style'] == 'infographic':
            animations.append(f'tl.fromTo("#scene-{i} .stat", {{opacity:0,y:40}}, {{opacity:1,y:0,duration:0.65,stagger:0.20,ease:"back.out(1.4)"}}, {start+.35:.3f});')
        elif scene['style'] == 'timeline':
            animations.append(f'tl.fromTo("#scene-{i} .events p", {{opacity:0,x:-70}}, {{opacity:1,x:0,duration:0.55,stagger:0.45,ease:"power2.out"}}, {start+.3:.3f});')
        elif scene['style'] == 'map':
            animations.append(f'tl.to("#route-{i}", {{strokeDashoffset:0,duration:{max(.6,length*.73):.3f},ease:"power1.inOut"}}, {start+.5:.3f});')
        elif scene['style'] in ('cinematic','archival','collage'):
            animations.append(f'tl.fromTo("#scene-{i} .planet", {{scale:0.82,rotation:-8,opacity:0.2}}, {{scale:1.08,rotation:4,opacity:1,duration:{max(.6,length*.85):.3f},ease:"sine.inOut"}}, {start+.15:.3f});')
    captions = []
    for i, cap in enumerate(props.get('captions', [])):
        start, length = cap['start'], max(.05, cap['end'] - cap['start'])
        captions.append(f'<div id="caption-{i}" class="clip caption" data-start="{start:.3f}" data-duration="{length:.3f}" data-track-index="1">{html.escape(cap["text"])}</div>')
    audio_tag = f'<audio data-start="0" data-duration="{dur:.3f}" data-track-index="2" src="./assets/narration.mp3"></audio>' if audio else ''
    document = f'''<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>{html.escape(props['title'])}</title><style>
*{{box-sizing:border-box}}html,body{{margin:0;background:#060e20;color:#f3f8ff;font-family:Arial,sans-serif}}
#root{{width:{width}px;height:{height}px;position:relative;overflow:hidden;background:radial-gradient(circle at 50% 38%,#264c7c,#080f21 68%);}}
.scene{{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;text-align:center;padding:{int(width*.10)}px;justify-content:flex-start;opacity:1;}}
.eyebrow{{position:absolute;top:10%;font-size:{int(width*.033)}px;letter-spacing:3px;color:#66e4f6;font-weight:bold}}
.head{{position:absolute;top:61%;left:8%;width:84%;font-size:{int(width*.083)}px;font-weight:900;line-height:1.08;text-wrap:balance;text-shadow:0 8px 22px #0009;overflow-wrap:break-word}}
.subhead{{position:absolute;top:76%;left:8%;width:84%;font-size:{int(width*.039)}px;color:#d2e7fa}}
.caption{{position:absolute;top:83%;left:12%;width:76%;padding:12px;border-radius:15px;background:#09182bdb;text-align:center;font-size:{int(width*.046)}px;font-weight:900;line-height:1.2}}
.orbit{{position:absolute;top:26%;left:13%;width:74%;height:31%;border:4px dashed #69bde199;border-radius:50%;display:flex;align-items:center;justify-content:center}}
.earth{{display:flex;align-items:center;justify-content:center;background:#267dc4;border-radius:50%;width:35%;aspect-ratio:1;font-size:{int(width*.030)}px;font-weight:bold}}
.moon{{position:absolute;right:-4%;top:35%;width:16%;aspect-ratio:1;border-radius:50%;background:radial-gradient(circle at 27% 28%,#fafafa,#637f97)}}
.planet{{position:absolute;top:22%;font-size:{int(width*.5)}px;color:#c9d5db;text-shadow:0 0 60px #acd2ff55}}
.stats{{position:absolute;top:30%;width:90%;display:flex;gap:12px;justify-content:space-around}}
.stat{{border:2px solid #55dce9;border-radius:18px;padding:18px;font-size:{int(width*.032)}px}}
.stat strong{{display:block;font-size:{int(width*.044)}px;margin-top:12px}}
.events{{position:absolute;top:26%;left:10%;width:80%;text-align:left;font-size:{int(width*.037)}px}}
.events b{{color:#f8d08b}}
.route-map{{position:absolute;top:24%;left:8%;width:84%;height:34%}}
.archival{{filter:sepia(.35)}}
.collage .planet{{text-shadow:-50px 35px #de8d9455,55px -25px #3edee366}}
</style></head><body>
<div id="root" data-composition-id="root" data-start="0" data-duration="{dur:.3f}" data-width="{width}" data-height="{height}">
{''.join(sections)}{''.join(captions)}{audio_tag}
</div>
<script src="https://cdn.jsdelivr.net/npm/gsap@3/dist/gsap.min.js"></script>
<script>window.__timelines = window.__timelines || {{}}; const tl=gsap.timeline({{paused:true}});\n{''.join(animations)}\ntl.set("#root",{{opacity:1}},{max(0,dur-.01):.3f});\nwindow.__timelines["root"]=tl;</script></body></html>'''
    (dest / 'index.html').write_text(document, encoding='utf-8')
    (dest / 'video-props.json').write_text(json.dumps(props, ensure_ascii=False, indent=2), encoding='utf-8')
    (dest / 'meta.json').write_text(json.dumps({'name': props['title'], 'generator': 'AI Video Factory v0.2'}, ensure_ascii=False, indent=2), encoding='utf-8')
    return dest / 'index.html'


def remotion_props(props, audio, slug):
    data = {k: props[k] for k in ('title', 'width', 'height', 'fps', 'scenes', 'captions')}
    if audio:
        public_path = ROOT / 'public' / 'generated' / slug
        public_path.mkdir(parents=True, exist_ok=True)
        # Use original audio format; remotion staticFile supports MP3 and WAV.
        target = public_path / ('narration' + audio.suffix)
        shutil.copy2(audio, target)
        data['audioSrc'] = f'generated/{slug}/{target.name}'
    return data


def render(args):
    project = load_project(args.project)
    if not command_available('ffmpeg') or not command_available('ffprobe'):
        raise RuntimeError('Instala FFmpeg y ffprobe antes de generar/renderizar.')
    slug = safe_slug(Path(args.project).stem)
    output = Path(args.out).resolve()
    stage = (ROOT / 'output' / '_engine_work' / f'{args.engine}-{slug}').resolve()
    props, audio = prepare(project, args.voice, stage)
    output.parent.mkdir(parents=True, exist_ok=True)
    if args.engine == 'remotion':
        doc = remotion_props(props, audio, slug)
        prop_file = (output if args.mode == 'generate' and output.suffix.lower() == '.json' else stage / 'remotion-props.json')
        prop_file.write_text(json.dumps(doc, ensure_ascii=False, indent=2), encoding='utf-8')
        if args.mode == 'generate':
            print('✓ Remotion props:', prop_file)
            return
        if not (ROOT / 'node_modules' / '@remotion' / 'cli').exists():
            raise RuntimeError('Falta Remotion. Ejecuta primero: python scripts/engines.py install')
        cmd = ['npx', '--no-install', 'remotion', 'render', 'engines/remotion/src/index.ts',
               'LunaExplicada', str(output), '--props=' + str(prop_file), '--codec=h264', '--pixel-format=yuv420p']
        subprocess.run(cmd, cwd=ROOT, check=True)
    elif args.engine == 'hyperframes':
        project_dir = (output if args.mode == 'generate' and output.suffix.lower() not in ('.mp4', '.mov') else stage / 'composition')
        index = generate_hyperframes(props, project_dir, audio)
        if args.mode == 'generate':
            print('✓ HyperFrames composition:', index)
            return
        for cmd in (['npx', '--yes', 'hyperframes', 'lint'],
                    ['npx', '--yes', 'hyperframes', 'check', '--json'],
                    ['npx', '--yes', 'hyperframes', 'render', '--quality', 'looks', '--output', str(output)]):
            subprocess.run(cmd, cwd=project_dir, check=True)
    else:
        raise ValueError('Motor no soportado: ' + args.engine)
    if not output.is_file() or output.stat().st_size == 0:
        raise RuntimeError('El motor no generó un MP4 válido')
    result = subprocess.run(['ffprobe','-v','error','-show_entries','format=duration:stream=codec_type,codec_name',
                             '-of','json',str(output)], capture_output=True, text=True, check=True)
    probe = json.loads(result.stdout)
    duration = float(probe['format']['duration'])
    if duration <= 0.5 or not any(x.get('codec_type') == 'video' for x in probe['streams']):
        raise RuntimeError('QC falló: video inválido')
    print(f'✓ MP4 confirmado: {output}, duración {duration:.2f}s')


def main():
    ap = argparse.ArgumentParser(description='Instalación y uso de Remotion y HyperFrames en AI Video Factory')
    sub = ap.add_subparsers(dest='action', required=True)
    sub.add_parser('doctor')
    inst = sub.add_parser('install'); inst.add_argument('--agent', default='codex', choices=('codex','claude-code','gemini-cli'))
    inst.add_argument('--skills', action='store_true', help='También instala skills oficiales desde GitHub mediante npx skills (requiere internet)')
    for action in ('render','generate'):
        cmd = sub.add_parser(action)
        cmd.add_argument('--engine', required=True, choices=('remotion','hyperframes'))
        cmd.add_argument('--project', default='projects/moon_demo.json')
        cmd.add_argument('--out', default='output/video.mp4')
        cmd.add_argument('--voice', default='none', choices=('none','auto','elevenlabs','local','espeak'))
        cmd.set_defaults(mode=action)
    args = ap.parse_args()
    try:
        if args.action == 'doctor': doctor()
        elif args.action == 'install': setup_engines(args.agent, args.skills)
        else: render(args)
    except (subprocess.CalledProcessError, RuntimeError, ValueError, FileNotFoundError) as exc:
        print('ERROR:', exc, file=sys.stderr)
        sys.exit(1)

if __name__ == '__main__':
    main()
