#!/usr/bin/env python3
"""Install only local Python dependencies; system FFmpeg must be installed explicitly."""
import os
import shutil
import subprocess
import sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
if sys.version_info<(3,10):
    raise SystemExit('Necesitas Python 3.10 o posterior.')
venv=root/'.venv'
if not venv.exists():
    subprocess.check_call([sys.executable,'-m','venv',str(venv)])
python=venv/('Scripts/python.exe' if os.name=='nt' else 'bin/python')
subprocess.check_call([str(python),'-m','pip','install','--upgrade','pip'])
subprocess.check_call([str(python),'-m','pip','install','-r',str(root/'requirements.txt')])
if not (root/'.env').exists():
    shutil.copyfile(root/'.env.example',root/'.env')
print('\nOK: entorno Python preparado.')
if not shutil.which('ffmpeg'):
    print('FALTA FFmpeg. Windows: winget install Gyan.FFmpeg; macOS: brew install ffmpeg; Linux: sudo apt install ffmpeg.')
if not (shutil.which('espeak') or shutil.which('espeak-ng')):
    print('Para la voz de demostración: Linux sudo apt install espeak-ng; Windows/macOS usan ElevenLabs en esta versión.')
print('Siguiente: configura .env para ElevenLabs, o usa --voice espeak si está instalado.')
print(f'Ejemplo: {python} scripts/make_video.py --project projects/moon_demo.json --out output/moon_demo')
