#!/usr/bin/env python3
"""Gestor opt-in de packs oficiales; no redistribuye código o videos ajenos.

Uso: python scripts/style_packs.py list|doctor|catalog|install [--pack ...] [--execute]
Instalaciones requieren red y consentimiento explícito (--execute).
"""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
DATA=json.loads((ROOT/'config/style-packs.json').read_text(encoding='utf-8'))
PACKS=DATA['packs']


def installed(pack):
    if pack == 'lemo-opuscar':
        return (ROOT/'vendor/lemo-opuscar/AGENTS.md').is_file() and (ROOT/'vendor/lemo-opuscar/styles').is_dir()
    if pack == 'claude-animation-base':
        return (ROOT/'vendor/claude-animation-base/ANIMATION_GUIDE.md').is_file()
    if pack == 'paper-shaders':
        return (ROOT/'node_modules/@paper-design/shaders-react/package.json').is_file()
    if pack == 'hyperframes-core-skills':
        return (ROOT/'.agents/skills/hyperframes/SKILL.md').is_file() or (ROOT/'.claude/skills/hyperframes/SKILL.md').is_file()
    return False


def cmd_list():
    print('AI Video Factory v0.3 / packs externos')
    for k,p in PACKS.items():
        status='INSTALADO (detectado)' if installed(k) else 'NO INSTALADO (opcional)'
        print(f'{k:26} {status:30} {p["type"]}')
    print('Nota: detectar ficheros no verifica el render ni la licencia de assets individuales.')


def cmd_doctor():
    for binary in ['python','git','node','npm','npx','ffmpeg','ffprobe']:
        print(f'{binary:12} {shutil.which(binary) or "FALTA"}')
    if shutil.which('node'):
        try:
            v=subprocess.check_output(['node','-p','process.versions.node'],text=True,timeout=10).strip()
            print('Node:',v,'(HyperFrames requiere >=22)')
        except (OSError,subprocess.SubprocessError) as e: print('No se pudo consultar Node:',e)
    cmd_list()


def run_checked(argv, cwd=ROOT):
    print('+',' '.join(str(x) for x in argv),flush=True)
    subprocess.run([str(a) for a in argv],cwd=cwd,check=True)


def attach_lemo_skill():
    source=ROOT/'vendor/lemo-opuscar/plugin/skills/lemo-opuscar'
    if not (source/'SKILL.md').is_file():
        print('Lemo: no se halló skill oficial en plugin/skills; usa skill local de puente.')
        return
    for folder in [ROOT/'.agents/skills/lemo-opuscar-official',ROOT/'.claude/skills/lemo-opuscar-official']:
        if folder.exists():
            print('Skill oficial ya existe; no sobrescribir:',folder)
            continue
        shutil.copytree(source,folder)
        print('Skill oficial copiada:',folder.relative_to(ROOT))


def install(pack,execute=False,with_deps=False):
    p=PACKS[pack]
    print('\nPACK',pack,'|', 'INSTALANDO' if execute else 'SIMULACIÓN')
    if pack in ['lemo-opuscar','claude-animation-base']:
        dst=ROOT/p['local']
        if not dst.exists():
            args=['git','clone','--depth','1',p['source'],str(dst)]
            if execute:
                if not shutil.which('git'): raise RuntimeError('Falta git; instálalo antes desde una fuente oficial.')
                dst.parent.mkdir(parents=True,exist_ok=True)
                run_checked(args)
            else: print('Se ejecutaría:',' '.join(args))
        else:
            print('Ya existe, no se modifica:',dst.relative_to(ROOT))
        if execute and pack=='lemo-opuscar' and dst.exists():
            attach_lemo_skill()
        if with_deps and pack=='lemo-opuscar':
            setup=dst/'plugin/skills/lemo-opuscar/scripts/setup.sh'
            if not setup.is_file():
                print('No se encuentra script oficial de preparación:',setup)
            elif execute:
                if os.name=='nt':
                    print('En Windows el setup.sh requiere Bash compatible. Sigue instrucciones del repositorio.')
                else:
                    # Es código de terceros: solo con --execute y --with-deps.
                    env=os.environ.copy();env['LEMO_OPUSCAR_HOME']=str(dst)
                    print('Ejecutando instalador oficial de Lemo; revisa el script antes de autorizar.')
                    subprocess.run(['sh',str(setup),'deps'],cwd=dst,check=True,env=env)
            else: print('Se ejecutaría: sh',setup,'deps (código externo)')
        if with_deps and pack=='claude-animation-base':
            if execute and (dst/'package-lock.json').is_file(): run_checked(['npm','ci'],cwd=dst)
            elif execute: print('No se encontró package-lock.json; revisa instalación manual.')
            else: print('Se ejecutaría: npm ci (en',dst,')')
    elif pack=='paper-shaders':
        cmd=['npm','install','--save-exact','@paper-design/shaders','@paper-design/shaders-react']
        if execute: run_checked(cmd)
        else: print('Se ejecutaría:',' '.join(cmd))
    elif pack=='hyperframes-core-skills':
        cmd=['npx','--yes','hyperframes','skills','update']
        if execute: run_checked(cmd)
        else: print('Se ejecutaría:',' '.join(cmd))
    if execute:
        print('Instalación terminada sin errores de subprocess; comprobando estado:',installed(pack))


def catalog(pack,filter_string=''):
    if pack != 'lemo-opuscar':
        print('El catálogo estructurado de STYLE.md aplica a lemo-opuscar.');return
    base=ROOT/'vendor/lemo-opuscar/styles'
    if not base.is_dir():
        print('Biblioteca Lemo no instalada. Ejecuta: python scripts/style_packs.py install --pack lemo-opuscar --execute')
        return
    files=sorted(base.glob('**/STYLE.md'))
    if not files: print('No se encontraron STYLE.md; revisa el checkout.')
    for f in files:
        rel=f.parent.relative_to(base).as_posix()
        if filter_string.lower() in rel.lower(): print(rel,'→',f.relative_to(ROOT).as_posix())
    print('Entradas encontradas:',len(files),'(no todas tienen validación con Codex)')


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    sub=ap.add_subparsers(dest='command',required=True)
    sub.add_parser('list');sub.add_parser('doctor')
    installer=sub.add_parser('install');installer.add_argument('--pack',default='all',choices=['all']+list(PACKS))
    installer.add_argument('--execute',action='store_true',help='Autoriza descargas/instalaciones de terceros. Sin esto solo simula.')
    installer.add_argument('--with-deps',action='store_true',help='Además ejecuta instaladores/dependencias de repos terceros.')
    cat=sub.add_parser('catalog');cat.add_argument('--pack',default='lemo-opuscar',choices=list(PACKS));cat.add_argument('--filter',default='')
    args=ap.parse_args()
    if args.command=='list':cmd_list()
    elif args.command=='doctor':cmd_doctor()
    elif args.command=='catalog':catalog(args.pack,args.filter)
    elif args.command=='install':
        for key in (list(PACKS) if args.pack=='all' else [args.pack]): install(key,args.execute,args.with_deps)
        print('\nNo se garantiza que las demos originales de terceros funcionen o que un modelo replique sus resultados.')

if __name__=='__main__':
    try: main()
    except (OSError,subprocess.CalledProcessError,RuntimeError) as err:
        print('ERROR:',err,file=sys.stderr);raise SystemExit(1)
