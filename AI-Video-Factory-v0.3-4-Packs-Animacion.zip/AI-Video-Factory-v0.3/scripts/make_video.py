#!/usr/bin/env python3
"""Run from anywhere, no manual PYTHONPATH needed."""
import argparse
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from video_factory.render import make_video

if __name__=='__main__':
    ap=argparse.ArgumentParser(description='AI Video Factory – JSON -> animated 9:16 MP4')
    ap.add_argument('--project',default='projects/moon_demo.json')
    ap.add_argument('--out',default='output/moon_demo')
    ap.add_argument('--voice',choices=['auto','elevenlabs','espeak','local'],default='auto')
    ap.add_argument('--width',type=int)
    ap.add_argument('--height',type=int)
    ap.add_argument('--fps',type=int)
    a=ap.parse_args()
    try:
        make_video(a.project,a.out,a.voice,a.width,a.height,a.fps)
    except Exception as exc:
        print('ERROR:',exc,file=sys.stderr)
        sys.exit(1)
