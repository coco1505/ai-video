---
name: storyboard
description: Traduce guion a escenas estructuradas JSON para el renderer y asigna estilos y recursos por beat.
---

# storyboard

Sigue la skill canónica en `.agents/skills/storyboard/SKILL.md` y `AGENTS.md`. Lee ese archivo para ejecutar el procedimiento completo. Este wrapper mantiene un solo lugar de mantenimiento y permite descubrimiento por Claude Code.
