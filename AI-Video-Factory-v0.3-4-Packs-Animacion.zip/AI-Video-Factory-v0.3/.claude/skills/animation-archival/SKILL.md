---
name: animation-archival
description: Crea estética de archivo histórico con imagen autorizada o recurso sepia procedural.
---

# animation-archival

Sigue la skill canónica en `.agents/skills/animation-archival/SKILL.md` y `AGENTS.md`. Lee ese archivo para ejecutar el procedimiento completo. Este wrapper mantiene un solo lugar de mantenimiento y permite descubrimiento por Claude Code.
