---
name: animation-collage
description: Compone collage editorial animado con paneles y titulares en documental o ensayo.
---

# animation-collage

Sigue la skill canónica en `.agents/skills/animation-collage/SKILL.md` y `AGENTS.md`. Lee ese archivo para ejecutar el procedimiento completo. Este wrapper mantiene un solo lugar de mantenimiento y permite descubrimiento por Claude Code.
