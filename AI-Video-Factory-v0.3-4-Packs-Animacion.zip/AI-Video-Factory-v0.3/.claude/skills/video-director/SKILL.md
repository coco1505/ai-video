---
name: video-director
description: Dirige el proceso completo desde un prompt hasta un MP4; úsala cada vez que pidan crear un video, reel, Short o documental.
---

# video-director

Sigue la skill canónica en `.agents/skills/video-director/SKILL.md` y `AGENTS.md`. Lee ese archivo para ejecutar el procedimiento completo. Este wrapper mantiene un solo lugar de mantenimiento y permite descubrimiento por Claude Code.
