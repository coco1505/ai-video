---
name: hook-retention
description: Optimiza el hook, estructura, claridad y retención de videos cortos divulgativos; úsala al escribir y revisar.
---

# hook-retention

Sigue la skill canónica en `.agents/skills/hook-retention/SKILL.md` y `AGENTS.md`. Lee ese archivo para ejecutar el procedimiento completo. Este wrapper mantiene un solo lugar de mantenimiento y permite descubrimiento por Claude Code.
