---
name: animation-cinematic
description: Crea documental cinematográfico con pan/zoom de imagen autorizada y encabezados editorializados.
---

# animation-cinematic

Sigue la skill canónica en `.agents/skills/animation-cinematic/SKILL.md` y `AGENTS.md`. Lee ese archivo para ejecutar el procedimiento completo. Este wrapper mantiene un solo lugar de mantenimiento y permite descubrimiento por Claude Code.
