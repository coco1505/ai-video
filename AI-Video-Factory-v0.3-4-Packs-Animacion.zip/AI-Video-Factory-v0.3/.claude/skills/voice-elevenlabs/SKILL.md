---
name: voice-elevenlabs
description: Genera narración con ElevenLabs y sincronización de palabras, o voz local demo si no hay API.
---

# voice-elevenlabs

Sigue la skill canónica en `.agents/skills/voice-elevenlabs/SKILL.md` y `AGENTS.md`. Lee ese archivo para ejecutar el procedimiento completo. Este wrapper mantiene un solo lugar de mantenimiento y permite descubrimiento por Claude Code.
