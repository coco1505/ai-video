---
name: research-factcheck
description: Investiga y verifica hechos documentales o científicos antes de escribir guiones, y registra fuentes reales.
---

# research-factcheck

Sigue la skill canónica en `.agents/skills/research-factcheck/SKILL.md` y `AGENTS.md`. Lee ese archivo para ejecutar el procedimiento completo. Este wrapper mantiene un solo lugar de mantenimiento y permite descubrimiento por Claude Code.
