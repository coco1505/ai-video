---
name: animation-infographic
description: Visualiza cifras, comparaciones y datos en tarjetas y barras animadas.
---

# animation-infographic

Sigue la skill canónica en `.agents/skills/animation-infographic/SKILL.md` y `AGENTS.md`. Lee ese archivo para ejecutar el procedimiento completo. Este wrapper mantiene un solo lugar de mantenimiento y permite descubrimiento por Claude Code.
