---
name: animation-kinetic
description: Crea titulares y tipografía cinética para ganchos, preguntas o conclusiones usando estilo kinetic.
---

# animation-kinetic

Sigue la skill canónica en `.agents/skills/animation-kinetic/SKILL.md` y `AGENTS.md`. Lee ese archivo para ejecutar el procedimiento completo. Este wrapper mantiene un solo lugar de mantenimiento y permite descubrimiento por Claude Code.
