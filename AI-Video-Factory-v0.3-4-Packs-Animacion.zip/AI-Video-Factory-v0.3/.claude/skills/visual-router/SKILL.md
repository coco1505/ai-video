---
name: visual-router
description: Elige automáticamente el estilo de animación más informativo para cada escena y evita efectos superfluos.
---

# visual-router

Sigue la skill canónica en `.agents/skills/visual-router/SKILL.md` y `AGENTS.md`. Lee ese archivo para ejecutar el procedimiento completo. Este wrapper mantiene un solo lugar de mantenimiento y permite descubrimiento por Claude Code.
