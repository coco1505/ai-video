---
name: captions-safezone
description: Produce subtítulos sincronizados y legibles para Shorts, Reels y TikTok.
---

# captions-safezone

Sigue la skill canónica en `.agents/skills/captions-safezone/SKILL.md` y `AGENTS.md`. Lee ese archivo para ejecutar el procedimiento completo. Este wrapper mantiene un solo lugar de mantenimiento y permite descubrimiento por Claude Code.
