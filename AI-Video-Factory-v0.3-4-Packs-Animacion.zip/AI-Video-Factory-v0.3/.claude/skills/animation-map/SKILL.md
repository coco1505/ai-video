---
name: animation-map
description: Genera mapas esquemáticos con puntos y líneas animadas para explicar rutas abstractas.
---

# animation-map

Sigue la skill canónica en `.agents/skills/animation-map/SKILL.md` y `AGENTS.md`. Lee ese archivo para ejecutar el procedimiento completo. Este wrapper mantiene un solo lugar de mantenimiento y permite descubrimiento por Claude Code.
