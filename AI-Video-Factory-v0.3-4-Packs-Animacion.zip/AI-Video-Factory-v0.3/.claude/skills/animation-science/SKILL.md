---
name: animation-science
description: Genera diagrama didáctico de rotación sincrónica Tierra-Luna con movimiento orbital.
---

# animation-science

Sigue la skill canónica en `.agents/skills/animation-science/SKILL.md` y `AGENTS.md`. Lee ese archivo para ejecutar el procedimiento completo. Este wrapper mantiene un solo lugar de mantenimiento y permite descubrimiento por Claude Code.
