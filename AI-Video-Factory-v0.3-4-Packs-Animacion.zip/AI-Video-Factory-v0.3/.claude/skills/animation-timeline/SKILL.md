---
name: animation-timeline
description: Construye líneas temporales animadas con fechas y eventos históricos.
---

# animation-timeline

Sigue la skill canónica en `.agents/skills/animation-timeline/SKILL.md` y `AGENTS.md`. Lee ese archivo para ejecutar el procedimiento completo. Este wrapper mantiene un solo lugar de mantenimiento y permite descubrimiento por Claude Code.
