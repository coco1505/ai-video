---
name: quality-control
description: Valida el MP4, subtítulos, audio, integridad de archivo y limitaciones antes de entregar.
---

# quality-control

Sigue la skill canónica en `.agents/skills/quality-control/SKILL.md` y `AGENTS.md`. Lee ese archivo para ejecutar el procedimiento completo. Este wrapper mantiene un solo lugar de mantenimiento y permite descubrimiento por Claude Code.
