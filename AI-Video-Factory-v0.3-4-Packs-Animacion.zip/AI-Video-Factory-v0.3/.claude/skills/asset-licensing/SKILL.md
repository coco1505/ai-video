---
name: asset-licensing
description: Comprueba derechos de fotos, footage, audio y stock; mantiene manifiesto antes de exportación.
---

# asset-licensing

Sigue la skill canónica en `.agents/skills/asset-licensing/SKILL.md` y `AGENTS.md`. Lee ese archivo para ejecutar el procedimiento completo. Este wrapper mantiene un solo lugar de mantenimiento y permite descubrimiento por Claude Code.
