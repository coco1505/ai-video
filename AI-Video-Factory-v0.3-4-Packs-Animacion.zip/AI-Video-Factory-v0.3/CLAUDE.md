# AI Video Factory — Claude Code
Lee `AGENTS.md` (reglas completas) y README.md. Las skills propias están en `.claude/skills/` y `.agents/skills/`. Para instalar las skills oficiales Remotion/HyperFrames en Claude Code utiliza `python scripts/engines.py install --skills --agent claude-code` cuando el usuario autorice descarga/instalación. No afirmar que los paquetes npm están incluidos en el ZIP. Respeta el motor que pida el usuario y verifica cada MP4.

## ACTUALIZACIÓN v0.3 · NUEVOS PACKS

La versión actual es **v0.3**. Lee `docs/STYLE_SELECTION.md`, `docs/THIRD_PARTY_STYLE_PACKS.md` y `.agents/skills/style-pack-director/SKILL.md` antes de trabajar con estilos avanzados.

- Ejecuta `python scripts/style_packs.py doctor` y `python scripts/style_packs.py list` para descubrir herramientas reales. Para revisar acciones antes de descargar usa `python scripts/style_packs.py install --pack all` (simulación). Solo instala tras consentimiento con `python scripts/style_packs.py install --pack all --execute`. En terceros, `--with-deps` ejecuta instaladores de sus repositorios y requiere revisión específica.
- **Lemo-Opuscar**: lee `vendor/lemo-opuscar/styles/<estilo>/STYLE.md`. Los 66 estilos anunciados son referencias del repositorio externo, NO implementaciones nativas certificadas en nuestro motor. Riesgo en Codex: creados para Claude Opus 5.5.
- **Claude Animation Base**: p5.js/p5.brush como proyecto aparte; estilos ilustrados artesanales. No confundas personaje de demo con una marca del cliente.
- **Paper Shaders**: demo opcional en `engines/remotion/src/paper-index.ts` mediante `npm run paper:render:demo` después de instalar el pack. Render WebGL pendiente de verificar.
- **HyperFrames**: CLI y core skills oficiales se instalan por `npx hyperframes skills update`; esto no sustituye validación de render.
- **Licencias**: solo el código propio viene en el ZIP; clones y paquetes terceros se obtienen de proveedores; respeta LICENSE/NOTICE y restricciones de audios de demos.
- Si usuario exige Remotion/HyperFrames/Lemo/p5 y no funciona, **informa del fallo**; no conviertas a legacy sin permiso.
