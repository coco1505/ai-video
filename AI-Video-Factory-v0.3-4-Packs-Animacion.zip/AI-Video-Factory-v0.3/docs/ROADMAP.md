# Iteraciones y condiciones de venta

## v0.1 — Cimientos (incluido ahora)
- [x] Estructura de carpetas agent-friendly sin instalación de skills globales
- [x] 8 skills de estilo + protocolos de producción
- [x] Ocho tipos de animación ejecutables en Pillow
- [x] JSON de escenas + renderer MP4 local con FFmpeg
- [x] ElevenLabs con timestamps + espeak demo, subtítulos SRT + quemados
- [x] Informes técnicos, fuentes, assets y contact sheet
- [ ] Tests de aceptación completos en Windows, macOS, Codex limpio, Claude Code, Antigravity

## v0.2 — Integración de motores (código y generadores incluidos; render npm pendiente)
- [x] Remotion + React/SVG con componentes iniciales y remotion CLI preparada (sin Three.js).
- [x] HyperFrames HTML/GSAP con clips y generador desde project.json; CLI externa descargable.
- [x] Skills locales de motores y script para descargar skills oficiales de ambos.
- [ ] Verificación real de render con npm y navegador en Codex limpio
- [ ] Componentes reales de diagramas de ciencias, mapas auténticos, gráficas con datos
- [ ] Transiciones más sofisticadas, microanimaciones y sistema de temas
- [ ] Cover, audio bed / SFX legítimos con licencias controladas y ducking
- [ ] Tests de legibilidad, clipping, silencio y frames negros

## v0.3 — Documentales completos
- [ ] Conector Pexels/Pixabay y búsqueda por escena con URLs y derechos
- [ ] Pan/zoom sobre video, clips stock y mezcla con Remotion
- [ ] Proveedores opcionales de imagen/video IA y presupuesto con aprobación
- [ ] Director visual por escena, consistencia temporal y de estilo

## v0.4 — Instalación y evaluación comercial
- [ ] Auto-installer multiplataforma robusto con instalación de FFmpeg aprobada
- [ ] Prueba a ciegas en Codex sin ninguna skill previa
- [ ] Loop automático de corrección visual/audio, auditoría de hechos
- [ ] Documentación, licencia comercial propia, privacidad, costes y pruebas por SO
- [ ] Beta real con compradores potenciales ANTES de cobrar
