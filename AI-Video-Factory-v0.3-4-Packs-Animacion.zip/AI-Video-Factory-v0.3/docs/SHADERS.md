# Demo: Paper Shaders + Remotion (opcional)

La integración no modifica el motor Remotion original hasta que instales la dependencia externa.

1. `python scripts/style_packs.py install --pack paper-shaders --execute` (ejecuta npm install exacto, con internet).
2. `npm run paper:compositions` lista la composición.
3. `npm run paper:render:demo` crea `output/paper-shader-intro.mp4` (si Chrome/WebGL y paquetes funcionan).
4. `ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1 output/paper-shader-intro.mp4` valida duración.

Este ejemplo usa **MeshGradient** de la biblioteca React oficial y anima la capa de fondo mediante el frame Remotion. `speed={0}` evita animación interna dependiente del reloj de Chrome. No promete texturas avanzadas en todos los dispositivos: WebGL/headless GPU puede fallar. El shader se ejecuta en el navegador, no es una imagen generada por IA. Preserva licencias Apache 2.0 y NOTICE si redistribuyes bibliotecas.
