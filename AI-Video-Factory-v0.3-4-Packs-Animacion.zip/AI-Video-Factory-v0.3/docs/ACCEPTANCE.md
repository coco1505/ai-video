# Prueba a ciegas en Codex (final de proyecto)

## Prueba en ambiente limpio

1. En otra computadora o sesión nueva de Codex sin skills globales propias, descomprime ZIP y abre **la raíz**.
2. Dile exactamente: `Quiero un video vertical de 45 segundos sobre por qué vemos siempre la misma cara de la Luna, en español, combinando 3D o motion graphics y estilo documental. Instala las dependencias necesarias de este repo, prepara el entorno, genera un MP4 final, ejecuta QC y entrégame el resultado.`
3. Valida el entorno y que el agente lee `AGENTS.md` y descubre skills sin instalación global.
4. Revisa que los hechos provienen de fuentes identificables; si no tiene web, debe indicar que falta investigación.
5. Confirma que crea un JSON ORIGINAL del tema, y no recicla sin cambios el ejemplo `moon_demo.json`.
6. Verifica la narración con voz de calidad y timestamps; si es voz demo, debe decirlo.
7. Verifica visualmente títulos, texto legible, clip inicial, transiciones y claridad del diagrama.
8. Inspecciona `master.mp4`, `captions.srt`, `qc-report.json`, `contact-sheet.png`, `sources.md`, `asset-manifest.json`.
9. Califica de 1 a 5: instalación, fidelidad factual, claridad, ritmo, calidad visual, sonido, sincronización, ausencia de errores.
10. Documenta errores de OS, dependencias, tiempo y costo real y usarlos para ajustar v0.2+.

## Criterios de aprobación v0.1 (limitados)
- Render reproduce como MP4 real H.264/AAC; QC técnico pasa.
- Skills se descubren desde carpeta del proyecto; lectura de `AGENTS.md` desencadena flujo.
- Diferentes estilos son ejecutables, no sólo una promesa.
- Audio ElevenLabs opcional; fallback local claramente marcado DEMO.
- Resultados y licencias documentados; assets no autorizados rechazados.

## No afirmar hasta probar
- Que un agente Codex/Claude/Antigravity efectivamente completa toda la cadena en SO externo sin intervención.
- Que el documental trae video de archivo real por defecto.
- Que soporte 3D real, mapas geográficos o Remotion está listo.
- Que el QC actual detecta automáticamente clipping, blackframes, sesgos o errores fácticos.

## Prueba adicional obligatoria para v0.2 en Codex limpio

- [ ] `python scripts/engines.py doctor` valida Node.js 22+, npm, FFmpeg y Python.
- [ ] `python scripts/engines.py install --skills --agent codex` descarga oficialmente las dependencias sin errores y deja la skills oficiales disponibles en Codex.
- [ ] `python scripts/engines.py generate --engine hyperframes --voice none --out output/luna-hyperframes/` genera HTML válido con timeline GSAP registrada.
- [ ] Dentro del proyecto HyperFrames se ejecuta `npx hyperframes lint`, `npx hyperframes check --json`, `npx hyperframes snapshot` y `npx hyperframes render`; se examinan fotogramas.
- [ ] `python scripts/engines.py render --engine remotion --project projects/moon_demo.json --voice local --out output/luna-remotion.mp4` genera MP4 con audio.
- [ ] `ffprobe` confirma códecs, dimensiones y duración del MP4 de CADA motor; no se entrega un HTML/JSON como MP4.
- [ ] Comparar visualmente ambos MP4, anotar clipping, legibilidad, transiciones, subtítulos, desincronía, calidad de voz y visuales genéricos.
- [ ] Prueba de ElevenLabs real sólo con consentimiento del gasto y clave aportada localmente por usuario.
- [ ] Probar Windows/macOS por separado antes de presentarlo como totalmente multiplataforma.

**Verificado en este entorno para v0.2:** generación de props Remotion y HTML HyperFrames y tests de código; el registro de npm no es accesible aquí, por lo tanto el render real con nuevos motores queda PENDIENTE.
