# Router de estilos · AI Video Factory v0.3

| Pedido de usuario | Herramienta sugerida | Estado |
|---|---|---|
| Animación científica / diagramas / órbitas / datos | Remotion React/SVG | Código en kit; CLI npm externa |
| Tipografía dinámica / transiciones HTML/GSAP | HyperFrames | Generador HTML en kit; CLI externa |
| Pizarra de tiza / CRT / mapa metro / estilos editoriales específicos | Lemo-Opuscar | Referencia `STYLE.md`; ejecución externa experimental |
| Personaje de cuento ilustrado / acuarela / dibujo artesanal | Claude Animation Base p5.js/p5.brush | Motor externo para animación artesanal |
| Degradados / grano / texturas de shader / fondos abstractos | Paper Shaders React/vanilla | Componente Remotion separado; necesita npm y WebGL |
| Sin conexión ni npm | Legacy Pillow/FFmpeg | MP4 de respaldo; estética más básica |

## Control de calidad para nuevos estilos

1. Hook visual en 0–2 s, no mantener un fondo de shader sin nueva información.
2. Primero un preview breve (5–10 s); evita producir 60 s si el motor falla.
3. No introducir 3D, metraje real o fuentes documentales inexistentes.
4. Reserva del tercio inferior para subtítulos; comprobar móvil.
5. Comparar fotogramas en t=0%,25%,50%,75%,100%; corregir clips vacíos, jitter, textos ocultos y transiciones.
6. Si se solicita un estilo Lemo exacto, citar el `STYLE.md` usado en el reporte y no prometer equivalencia 1:1.
