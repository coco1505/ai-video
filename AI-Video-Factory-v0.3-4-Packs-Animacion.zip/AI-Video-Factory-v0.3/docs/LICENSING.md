# Licencias y redistribución (léelo antes de vender AI Video Factory)

**AI Video Factory v0.2** incluye código propio en Python/React/HTML/skills. Este ZIP **NO** incluye el código ni los binarios de Remotion, HyperFrames o GSAP, y tampoco concede derechos de uso sobre esas marcas o paquetes. Las integraciones se instalan desde sus fuentes oficiales en el equipo del usuario, con internet y bajo sus licencias.

- **Remotion:** licencia propietaria (NO OSI open source). En 2026, individuos y organizaciones de hasta 3 personas calificadas generalmente pueden usarlo gratis incluso comercialmente; equipos de 4+ personas requieren una licencia según el uso. Los productos automatizados pueden necesitar el plan Remotion for Automators. Revisa condiciones antes de distribuir, vender, sublicenciar o incluir código de terceros en un producto. No copies el motor Remotion ni lo ofrezcas como un derivado independiente. Condiciones: https://www.remotion.dev/docs/terms y precios: https://www.remotion.dev/docs/license/pricing.
- **HyperFrames:** proyecto oficial HeyGen `heygen-com/hyperframes`. Instalación a través de `npx hyperframes` y skills oficiales por `npx skills add heygen-com/hyperframes`. Verifica la licencia vigente de cada archivo/paquete antes de redistribuirlo. Este kit **no incluye** el código fuente de HyperFrames. Docs: https://hyperframes.app/docs/1-startup/2-quickstart.
- **GSAP:** HyperFrames usa GSAP. La demo lo obtiene desde el CDN, sin redistribuir librerías localmente. Asegura cumplimiento de licencias aplicables a cualquier distribución y entorno comercial.
- **ElevenLabs:** API externa con costos, cuotas y términos propios. Credenciales en `.env` privado; consulta consentimiento antes de hacer llamadas de pago.
- **Assets:** el ZIP no redistribuye imágenes, audio, videos ni música comerciales de terceros. Verifica siempre licencia, fuente, atribución y autorización.

El precio de venta de nuestro **instalador, orquestador, skills propias y templates propios** no debe representar la concesión de licencia de Remotion/HyperFrames. Una futura edición comercial debe incluir un análisis legal actualizado y comprobar condiciones por país.

## v0.3 packs externos: matices adicionales

- Lemo-Opuscar, `lemomo-ai/lemo-opuscar`: código+documentación MIT; películas de demostración y fotogramas CC BY 4.0, con atribución y declaración de cambios; algunas pistas de narración y assets externos excluidos. No redistribuir material de demos sin auditoría.
- Claude Animation Base, `JohnHeibel/ClaudeAnimationBase`: MIT; conservar aviso de licencia en código derivado. No asumir derechos de marca sobre Clawd.
- Paper Shaders, `paper-design/shaders`: Apache 2.0, incluye NOTICE; usar en videos comerciales está permitido bajo términos del proyecto, conservar LICENSE/NOTICE al redistribuir código.
- HyperFrames, `heygen-com/hyperframes`: Apache 2.0; las integraciones de servicios HeyGen siguen reglas propias.

La instalación en vivo desde repositorios/npm reduce archivos distribuidos, pero NO elimina requisitos de licencia y seguridad. Versionar y auditar los paquetes antes del producto vendible.
