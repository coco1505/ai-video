# `project.json` — contrato de video v0.1

```json
{
  "title": "Explicación original",
  "language": "es-MX",
  "mode": "hybrid",
  "width": 720,
  "height": 1280,
  "fps": 24,
  "sources": ["https://example.org/actual-source"],
  "social_caption": "...",
  "scenes": [
    {"style":"kinetic","headline":"TEXTO CORTO","narration":"Voz de esta escena."},
    {"style":"science","headline":"ROTACIÓN","subhead":"Una vuelta por órbita","narration":"..."},
    {"style":"infographic","headline":"CIFRAS","stats":[{"label":"A","value":"10"}],"narration":"..."},
    {"style":"timeline","headline":"CRONOLOGÍA","events":[{"year":"1969","label":"Ejemplo"}],"narration":"..."},
    {"style":"map","headline":"RUTA","points":[[0.2,0.3],[0.6,0.7]],"narration":"..."}
  ]
}
```

- `scenes` 1 a 60; `style` es uno de 8 nombres soportados; `headline` max recomendable 5-8 palabras; `narration` obligatorio.
- `width`, `height` pares; 9:16 recomendado; fps 24 o 30 para producción.
- `cinematic` y `archival` pueden recibir una imagen fija real con `asset` (ruta relativa al `project.json`), `source_url` y `license`. También `creator` opcional. Vídeo stock aún no admitido en esta etapa; sólo imágenes compatibles con Pillow.
- `map` recibe puntos NORMALIZADOS de 0 a 1, NO latitud/longitud ni datos de mapa reales.
- `science` es un diagrama astronómico específico de órbita lunar, NO un motor universal de física. Para otros temas usa `infographic`, `timeline`, `kinetic` o crea un plugin futuro.
- El agente crea contenido y decide escena por escena. El renderer NO crea guiones ni investiga por sí solo.
- La duración final la determina el audio y se reparte por los tiempos reales de ElevenLabs si hay alignment; en espeak el reparto es una aproximación por longitud textual.
- Los captions de ElevenLabs tienen timestamps reales por carácter; con espeak se distribuyen proporcionalmente y requieren revisión.
