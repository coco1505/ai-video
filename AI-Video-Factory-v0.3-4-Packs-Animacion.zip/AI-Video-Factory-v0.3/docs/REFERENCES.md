# Referencias externas para mejorar la fábrica

- OpenAI/Codex skills: https://learn.chatgpt.com/docs/build-skills
- Google Antigravity skills: https://antigravity.google/docs/skills
- Remotion agent skills: https://www.remotion.dev/docs/ai/skills
- ElevenLabs voice + timestamps: https://elevenlabs.io/docs/api-reference/text-to-speech/convert-with-timestamps
- YouTube Shorts discovery: https://support.google.com/youtube/answer/11914225?co=YOUTUBE._YTVideoType%3Dshorts&hl=en
- TikTok video creative: https://ads.tiktok.com/business/en/guides/video-advertising-guide
- Open-source ideas (inspect licenses before copying!): https://github.com/DojoCodingLabs/remotion-superpowers
- Open-source JSON-driven renderer pattern: https://github.com/social-media-skills/remotion-shorts-skill

## Hipótesis de diseño por validar
- El hook claro en los primeros 2-3 segundos podría elevar permanencia en algunos nichos; NO es garantía de viralidad.
- La frecuencia de cambios visuales debe acompañar a la información, no ser un corte arbitrario cada N segundos.
- La calidad narrativa y la originalidad importan más que el número de efectos. Medir vistas, retención media, rewatches y finalizaciones en pruebas reales.
