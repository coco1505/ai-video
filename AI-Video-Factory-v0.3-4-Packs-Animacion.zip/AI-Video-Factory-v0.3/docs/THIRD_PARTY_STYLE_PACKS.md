# Packs externos, 2026-11-08

No hay copia de repositorios de terceros dentro del ZIP. Se instala contenido **desde las fuentes oficiales a elección del usuario**. El script ofrece primero simulación de comandos para revisión de seguridad.

## Empezar

```bash
python scripts/style_packs.py doctor
python scripts/style_packs.py list
python scripts/style_packs.py install --pack all          # SIMULA, no descarga
python scripts/style_packs.py install --pack all --execute   # DESCARGA realmente tras autorización
python scripts/style_packs.py catalog --pack lemo-opuscar
```

**Diferencias**

- `hyperframes-core-skills`: usa `npx --yes hyperframes skills update` desde npm. Instala el **núcleo oficial** compatible con CLI; no incluye todas las skills opcionales de HyperFrames. Requiere Node 22+ e internet; se deja separado del setup anterior para usar el método oficial más reciente.
- `lemo-opuscar`: descarga `https://github.com/lemomo-ai/lemo-opuscar.git` a `vendor/lemo-opuscar/`. Copia la skill oficial a las carpetas de Codex y Claude cuando existe. El uso de estilos se rige por `vendor/lemo-opuscar/AGENTS.md`, `DIRECTOR.md`, `TECHNIQUE.md` y cada `styles/*/STYLE.md`. Instalar las dependencias del pipeline externo NO ocurre por defecto; `--with-deps` ejecuta el setup del autor si hay Bash, después de revisar sus scripts. Requiere Node 20+, FFmpeg 7+, Python 3.11+. Los autores optimizan la reproducción para Claude Opus 5.5 y **no garantizan Codex**.
- `claude-animation-base`: descarga el repo a `vendor/claude-animation-base/`. Los archivos y guías están disponibles como referencia; `--with-deps` puede ejecutar `npm ci` en su carpeta. Es un proyecto de personajes p5.js/p5.brush, **no es un plugin general de Remotion** ni una biblioteca de personajes licenciada para marcas ajenas.
- `paper-shaders`: ejecuta `npm install --save-exact @paper-design/shaders @paper-design/shaders-react`. Demo opcional en `engines/remotion/src/paper-index.ts`. Requiere WebGL que funcione en Chromium headless. Ver `docs/SHADERS.md`.

**Niveles de integración:** Remotion y HyperFrames ya tienen puentes propios en v0.2 (render no verificado con npm); Paper Shaders tiene composición React separada real y ejecutable al instalar su paquete; Lemo-Opuscar y Claude Animation Base se integran como repositorios/skills de estilo opcionales, no como un renderizador universal con la CLI `scripts/engines.py`.

## Licencias y comercialización

- HyperFrames (HeyGen): Apache 2.0.
- Paper Shaders: Apache 2.0; conservar LICENSE y NOTICE al redistribuir código.
- ClaudeAnimationBase: MIT; conservar aviso de derechos y licencia si reutilizas código.
- Lemo-Opuscar: código y guías MIT; vídeos de demostración y fotogramas CC BY 4.0 con atribución; algunos audios excluidos y assets externos sujetos a términos independientes.
- Remotion: licencia propia, distinta de open source. Comprobar modelo de negocio de automatización antes de vender el kit.

Verificar siempre licencias vigentes y cadenas de dependencias; este texto no es asesoría legal.

## Fuentes originales

- https://github.com/heygen-com/hyperframes
- https://github.com/lemomo-ai/lemo-opuscar
- https://github.com/JohnHeibel/ClaudeAnimationBase
- https://github.com/paper-design/shaders
